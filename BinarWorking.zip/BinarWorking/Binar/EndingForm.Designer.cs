﻿namespace Binar
{
    partial class EndingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        public System.ComponentModel.IContainer components = null;
        

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EndingForm));
            this.Close = new Guna.UI2.WinForms.Guna2CircleButton();
            this.MovingPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.History = new Guna.UI2.WinForms.Guna2Button();
            this.FullTime = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.G3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.G4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.G5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.G6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.T1 = new System.Windows.Forms.Label();
            this.T2 = new System.Windows.Forms.Label();
            this.T3 = new System.Windows.Forms.Label();
            this.T4 = new System.Windows.Forms.Label();
            this.T5 = new System.Windows.Forms.Label();
            this.T6 = new System.Windows.Forms.Label();
            this.G7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.T7 = new System.Windows.Forms.Label();
            this.G2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.G1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.HistoryPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.UkazatelVyberu = new System.Windows.Forms.Label();
            this.PodtextUkazatGraf = new System.Windows.Forms.Label();
            this.Ukazatgraf = new Guna.UI2.WinForms.Guna2Button();
            this.PodtextPomerit = new System.Windows.Forms.Label();
            this.Pomerit = new Guna.UI2.WinForms.Guna2Button();
            this.VyberZaznamu = new Guna.UI2.WinForms.Guna2Panel();
            this.PredlohaVyberuHistorie = new Guna.UI2.WinForms.Guna2Button();
            this.UkazaniGrafuZaznam = new Guna.UI2.WinForms.Guna2Panel();
            this.Legenda = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.MainPomerCas7 = new System.Windows.Forms.Label();
            this.MainPomerCas6 = new System.Windows.Forms.Label();
            this.MainPomerCas5 = new System.Windows.Forms.Label();
            this.MainPomerCas4 = new System.Windows.Forms.Label();
            this.MainPomerCas3 = new System.Windows.Forms.Label();
            this.MainPomerCas2 = new System.Windows.Forms.Label();
            this.MainPomerCas1 = new System.Windows.Forms.Label();
            this.MainPomerGraf7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.MainPomerGraf1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.MainPomerGraf6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.MainPomerGraf5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.MainPomerGraf4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.MainPomerGraf3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.MainPomerGraf2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.PomerCas7 = new System.Windows.Forms.Label();
            this.PomerCas6 = new System.Windows.Forms.Label();
            this.PomerCas5 = new System.Windows.Forms.Label();
            this.PomerCas4 = new System.Windows.Forms.Label();
            this.PomerCas3 = new System.Windows.Forms.Label();
            this.PomerCas2 = new System.Windows.Forms.Label();
            this.PomerCas1 = new System.Windows.Forms.Label();
            this.JmenoHistorie = new System.Windows.Forms.Label();
            this.PomerPrumernyCas = new System.Windows.Forms.Label();
            this.PomerGraf7 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.PomerGraf1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.PomerGraf6 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.PomerGraf5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.PomerGraf4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.PomerGraf3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.PomerGraf2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.MovingPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.G3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.G1)).BeginInit();
            this.HistoryPanel.SuspendLayout();
            this.VyberZaznamu.SuspendLayout();
            this.UkazaniGrafuZaznam.SuspendLayout();
            this.Legenda.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf2)).BeginInit();
            this.SuspendLayout();
            // 
            // Close
            // 
            this.Close.Animated = true;
            this.Close.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.BorderThickness = 3;
            this.Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Close.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Close.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Close.FillColor = System.Drawing.Color.Maroon;
            this.Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold);
            this.Close.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.ForeColor = System.Drawing.Color.Maroon;
            this.Close.Location = new System.Drawing.Point(24, 42);
            this.Close.Name = "Close";
            this.Close.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Close.Size = new System.Drawing.Size(50, 50);
            this.Close.TabIndex = 33;
            this.Close.TabStop = false;
            this.Close.Text = "X";
            this.Close.TextOffset = new System.Drawing.Point(1, 1);
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // MovingPanel
            // 
            this.MovingPanel.BackColor = System.Drawing.Color.Transparent;
            this.MovingPanel.BorderColor = System.Drawing.Color.Black;
            this.MovingPanel.BorderRadius = 50;
            this.MovingPanel.BorderThickness = 3;
            this.MovingPanel.Controls.Add(this.History);
            this.MovingPanel.Controls.Add(this.Close);
            this.MovingPanel.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.MovingPanel.FillColor = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor2 = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor3 = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor4 = System.Drawing.Color.Transparent;
            this.MovingPanel.Location = new System.Drawing.Point(-12, -30);
            this.MovingPanel.Name = "MovingPanel";
            this.MovingPanel.Quality = 100;
            this.MovingPanel.Size = new System.Drawing.Size(1025, 108);
            this.MovingPanel.TabIndex = 36;
            // 
            // History
            // 
            this.History.Animated = true;
            this.History.AutoRoundedCorners = true;
            this.History.BackColor = System.Drawing.Color.Transparent;
            this.History.BorderRadius = 21;
            this.History.Cursor = System.Windows.Forms.Cursors.Hand;
            this.History.CustomBorderColor = System.Drawing.Color.White;
            this.History.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.History.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.History.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.History.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.History.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.History.Font = new System.Drawing.Font("Arial Black", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World);
            this.History.ForeColor = System.Drawing.Color.Olive;
            this.History.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.History.HoverState.CustomBorderColor = System.Drawing.Color.Transparent;
            this.History.HoverState.FillColor = System.Drawing.Color.Olive;
            this.History.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.History.Location = new System.Drawing.Point(798, 47);
            this.History.Name = "History";
            this.History.PressedDepth = 0;
            this.History.Size = new System.Drawing.Size(175, 45);
            this.History.TabIndex = 165;
            this.History.TabStop = false;
            this.History.Text = "Historie";
            this.History.TextOffset = new System.Drawing.Point(2, 0);
            this.History.Click += new System.EventHandler(this.History_Click);
            // 
            // FullTime
            // 
            this.FullTime.AutoSize = true;
            this.FullTime.Font = new System.Drawing.Font("Arial Black", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.FullTime.ForeColor = System.Drawing.Color.White;
            this.FullTime.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.FullTime.Location = new System.Drawing.Point(328, 81);
            this.FullTime.Margin = new System.Windows.Forms.Padding(0);
            this.FullTime.Name = "FullTime";
            this.FullTime.Size = new System.Drawing.Size(296, 38);
            this.FullTime.TabIndex = 165;
            this.FullTime.Text = "Průměrný Čas: 10s";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.ForeColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(0, 443);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1025, 61);
            this.panel2.TabIndex = 135;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(229, 465);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 32);
            this.label1.TabIndex = 137;
            this.label1.Text = "Ř 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(104, 465);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 32);
            this.label2.TabIndex = 138;
            this.label2.Text = "Ř 1";
            // 
            // G3
            // 
            this.G3.BackColor = System.Drawing.Color.Transparent;
            this.G3.BorderRadius = 20;
            this.G3.Cursor = System.Windows.Forms.Cursors.Help;
            this.G3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.G3.ImageRotate = 0F;
            this.G3.Location = new System.Drawing.Point(360, 390);
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(46, 72);
            this.G3.TabIndex = 141;
            this.G3.TabStop = false;
            this.G3.UseTransparentBackground = true;
            // 
            // G4
            // 
            this.G4.BackColor = System.Drawing.Color.Transparent;
            this.G4.BorderRadius = 20;
            this.G4.Cursor = System.Windows.Forms.Cursors.Help;
            this.G4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.G4.ImageRotate = 0F;
            this.G4.Location = new System.Drawing.Point(486, 390);
            this.G4.Name = "G4";
            this.G4.Size = new System.Drawing.Size(46, 72);
            this.G4.TabIndex = 143;
            this.G4.TabStop = false;
            this.G4.UseTransparentBackground = true;
            // 
            // G5
            // 
            this.G5.BackColor = System.Drawing.Color.Transparent;
            this.G5.BorderRadius = 20;
            this.G5.Cursor = System.Windows.Forms.Cursors.Help;
            this.G5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.G5.ImageRotate = 0F;
            this.G5.Location = new System.Drawing.Point(611, 390);
            this.G5.Name = "G5";
            this.G5.Size = new System.Drawing.Size(46, 72);
            this.G5.TabIndex = 145;
            this.G5.TabStop = false;
            this.G5.UseTransparentBackground = true;
            // 
            // G6
            // 
            this.G6.BackColor = System.Drawing.Color.Transparent;
            this.G6.BorderRadius = 20;
            this.G6.Cursor = System.Windows.Forms.Cursors.Help;
            this.G6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.G6.ImageRotate = 0F;
            this.G6.Location = new System.Drawing.Point(738, 390);
            this.G6.Name = "G6";
            this.G6.Size = new System.Drawing.Size(46, 72);
            this.G6.TabIndex = 147;
            this.G6.TabStop = false;
            this.G6.UseTransparentBackground = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(355, 465);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 32);
            this.label3.TabIndex = 151;
            this.label3.Text = "Ř 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(480, 465);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 32);
            this.label4.TabIndex = 150;
            this.label4.Text = "Ř 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label5.Location = new System.Drawing.Point(607, 465);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 32);
            this.label5.TabIndex = 153;
            this.label5.Text = "Ř 5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(732, 465);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 32);
            this.label6.TabIndex = 152;
            this.label6.Text = "Ř 6";
            // 
            // T1
            // 
            this.T1.AutoSize = true;
            this.T1.BackColor = System.Drawing.Color.Transparent;
            this.T1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.T1.ForeColor = System.Drawing.Color.White;
            this.T1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.T1.Location = new System.Drawing.Point(90, 355);
            this.T1.Margin = new System.Windows.Forms.Padding(0);
            this.T1.Name = "T1";
            this.T1.Size = new System.Drawing.Size(88, 32);
            this.T1.TabIndex = 155;
            this.T1.Text = "1000s";
            // 
            // T2
            // 
            this.T2.AutoSize = true;
            this.T2.BackColor = System.Drawing.Color.Transparent;
            this.T2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.T2.ForeColor = System.Drawing.Color.White;
            this.T2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.T2.Location = new System.Drawing.Point(219, 355);
            this.T2.Margin = new System.Windows.Forms.Padding(0);
            this.T2.Name = "T2";
            this.T2.Size = new System.Drawing.Size(88, 32);
            this.T2.TabIndex = 156;
            this.T2.Text = "1000s";
            // 
            // T3
            // 
            this.T3.AutoSize = true;
            this.T3.BackColor = System.Drawing.Color.Transparent;
            this.T3.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.T3.ForeColor = System.Drawing.Color.White;
            this.T3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.T3.Location = new System.Drawing.Point(341, 355);
            this.T3.Margin = new System.Windows.Forms.Padding(0);
            this.T3.Name = "T3";
            this.T3.Size = new System.Drawing.Size(88, 32);
            this.T3.TabIndex = 157;
            this.T3.Text = "1000s";
            // 
            // T4
            // 
            this.T4.AutoSize = true;
            this.T4.BackColor = System.Drawing.Color.Transparent;
            this.T4.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.T4.ForeColor = System.Drawing.Color.White;
            this.T4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.T4.Location = new System.Drawing.Point(474, 355);
            this.T4.Margin = new System.Windows.Forms.Padding(0);
            this.T4.Name = "T4";
            this.T4.Size = new System.Drawing.Size(58, 32);
            this.T4.TabIndex = 158;
            this.T4.Text = "10s";
            // 
            // T5
            // 
            this.T5.AutoSize = true;
            this.T5.BackColor = System.Drawing.Color.Transparent;
            this.T5.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.T5.ForeColor = System.Drawing.Color.White;
            this.T5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.T5.Location = new System.Drawing.Point(599, 355);
            this.T5.Margin = new System.Windows.Forms.Padding(0);
            this.T5.Name = "T5";
            this.T5.Size = new System.Drawing.Size(58, 32);
            this.T5.TabIndex = 159;
            this.T5.Text = "10s";
            // 
            // T6
            // 
            this.T6.AutoSize = true;
            this.T6.BackColor = System.Drawing.Color.Transparent;
            this.T6.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.T6.ForeColor = System.Drawing.Color.White;
            this.T6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.T6.Location = new System.Drawing.Point(732, 355);
            this.T6.Margin = new System.Windows.Forms.Padding(0);
            this.T6.Name = "T6";
            this.T6.Size = new System.Drawing.Size(58, 32);
            this.T6.TabIndex = 160;
            this.T6.Text = "10s";
            // 
            // G7
            // 
            this.G7.BackColor = System.Drawing.Color.Transparent;
            this.G7.BorderRadius = 20;
            this.G7.Cursor = System.Windows.Forms.Cursors.Help;
            this.G7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.G7.ImageRotate = 0F;
            this.G7.Location = new System.Drawing.Point(864, 390);
            this.G7.Name = "G7";
            this.G7.Size = new System.Drawing.Size(46, 72);
            this.G7.TabIndex = 162;
            this.G7.TabStop = false;
            this.G7.UseTransparentBackground = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label12.Location = new System.Drawing.Point(859, 465);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 32);
            this.label12.TabIndex = 163;
            this.label12.Text = "Ř 7";
            // 
            // T7
            // 
            this.T7.AutoSize = true;
            this.T7.BackColor = System.Drawing.Color.Transparent;
            this.T7.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.T7.ForeColor = System.Drawing.Color.White;
            this.T7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.T7.Location = new System.Drawing.Point(858, 355);
            this.T7.Margin = new System.Windows.Forms.Padding(0);
            this.T7.Name = "T7";
            this.T7.Size = new System.Drawing.Size(58, 32);
            this.T7.TabIndex = 164;
            this.T7.Text = "10s";
            // 
            // G2
            // 
            this.G2.BackColor = System.Drawing.Color.Transparent;
            this.G2.BorderRadius = 20;
            this.G2.Cursor = System.Windows.Forms.Cursors.Help;
            this.G2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.G2.ImageRotate = 0F;
            this.G2.Location = new System.Drawing.Point(235, 390);
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(46, 72);
            this.G2.TabIndex = 139;
            this.G2.TabStop = false;
            this.G2.UseTransparentBackground = true;
            // 
            // G1
            // 
            this.G1.BackColor = System.Drawing.Color.Transparent;
            this.G1.BorderRadius = 20;
            this.G1.Cursor = System.Windows.Forms.Cursors.Help;
            this.G1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.G1.ImageRotate = 0F;
            this.G1.Location = new System.Drawing.Point(110, 390);
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(46, 72);
            this.G1.TabIndex = 154;
            this.G1.TabStop = false;
            this.G1.UseTransparentBackground = true;
            // 
            // HistoryPanel
            // 
            this.HistoryPanel.Controls.Add(this.UkazatelVyberu);
            this.HistoryPanel.Controls.Add(this.PodtextUkazatGraf);
            this.HistoryPanel.Controls.Add(this.Ukazatgraf);
            this.HistoryPanel.Controls.Add(this.PodtextPomerit);
            this.HistoryPanel.Controls.Add(this.Pomerit);
            this.HistoryPanel.Controls.Add(this.VyberZaznamu);
            this.HistoryPanel.Location = new System.Drawing.Point(0, 81);
            this.HistoryPanel.Name = "HistoryPanel";
            this.HistoryPanel.Size = new System.Drawing.Size(1000, 423);
            this.HistoryPanel.TabIndex = 165;
            this.HistoryPanel.Visible = false;
            // 
            // UkazatelVyberu
            // 
            this.UkazatelVyberu.AutoSize = true;
            this.UkazatelVyberu.Font = new System.Drawing.Font("Arial Black", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.UkazatelVyberu.ForeColor = System.Drawing.Color.Gray;
            this.UkazatelVyberu.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.UkazatelVyberu.Location = new System.Drawing.Point(730, 44);
            this.UkazatelVyberu.Margin = new System.Windows.Forms.Padding(0);
            this.UkazatelVyberu.Name = "UkazatelVyberu";
            this.UkazatelVyberu.Size = new System.Drawing.Size(0, 48);
            this.UkazatelVyberu.TabIndex = 188;
            // 
            // PodtextUkazatGraf
            // 
            this.PodtextUkazatGraf.AutoSize = true;
            this.PodtextUkazatGraf.ForeColor = System.Drawing.Color.White;
            this.PodtextUkazatGraf.Location = new System.Drawing.Point(783, 339);
            this.PodtextUkazatGraf.Name = "PodtextUkazatGraf";
            this.PodtextUkazatGraf.Size = new System.Drawing.Size(99, 13);
            this.PodtextUkazatGraf.TabIndex = 169;
            this.PodtextUkazatGraf.Text = "Ukáže vybraný graf";
            this.PodtextUkazatGraf.Visible = false;
            // 
            // Ukazatgraf
            // 
            this.Ukazatgraf.Animated = true;
            this.Ukazatgraf.AutoRoundedCorners = true;
            this.Ukazatgraf.BackColor = System.Drawing.Color.Transparent;
            this.Ukazatgraf.BorderRadius = 29;
            this.Ukazatgraf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Ukazatgraf.CustomBorderColor = System.Drawing.Color.White;
            this.Ukazatgraf.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Ukazatgraf.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Ukazatgraf.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Ukazatgraf.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Ukazatgraf.FillColor = System.Drawing.Color.White;
            this.Ukazatgraf.Font = new System.Drawing.Font("Arial Black", 35F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World);
            this.Ukazatgraf.ForeColor = System.Drawing.Color.Black;
            this.Ukazatgraf.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.Ukazatgraf.HoverState.CustomBorderColor = System.Drawing.Color.Transparent;
            this.Ukazatgraf.HoverState.FillColor = System.Drawing.Color.Black;
            this.Ukazatgraf.HoverState.ForeColor = System.Drawing.Color.White;
            this.Ukazatgraf.Location = new System.Drawing.Point(683, 276);
            this.Ukazatgraf.Name = "Ukazatgraf";
            this.Ukazatgraf.PressedDepth = 0;
            this.Ukazatgraf.Size = new System.Drawing.Size(288, 60);
            this.Ukazatgraf.TabIndex = 168;
            this.Ukazatgraf.TabStop = false;
            this.Ukazatgraf.Text = "Ukázat graf";
            this.Ukazatgraf.TextOffset = new System.Drawing.Point(2, 0);
            this.Ukazatgraf.Visible = false;
            this.Ukazatgraf.Click += new System.EventHandler(this.UkazatGraf_Click);
            // 
            // PodtextPomerit
            // 
            this.PodtextPomerit.AutoSize = true;
            this.PodtextPomerit.ForeColor = System.Drawing.Color.White;
            this.PodtextPomerit.Location = new System.Drawing.Point(741, 226);
            this.PodtextPomerit.Name = "PodtextPomerit";
            this.PodtextPomerit.Size = new System.Drawing.Size(175, 13);
            this.PodtextPomerit.TabIndex = 167;
            this.PodtextPomerit.Text = "Poměřuje s aktuálníma výsledkama";
            this.PodtextPomerit.Visible = false;
            // 
            // Pomerit
            // 
            this.Pomerit.Animated = true;
            this.Pomerit.AutoRoundedCorners = true;
            this.Pomerit.BackColor = System.Drawing.Color.Transparent;
            this.Pomerit.BorderRadius = 29;
            this.Pomerit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Pomerit.CustomBorderColor = System.Drawing.Color.White;
            this.Pomerit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Pomerit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Pomerit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Pomerit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Pomerit.FillColor = System.Drawing.Color.White;
            this.Pomerit.Font = new System.Drawing.Font("Arial Black", 35F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World);
            this.Pomerit.ForeColor = System.Drawing.Color.Black;
            this.Pomerit.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.Pomerit.HoverState.CustomBorderColor = System.Drawing.Color.Transparent;
            this.Pomerit.HoverState.FillColor = System.Drawing.Color.Black;
            this.Pomerit.HoverState.ForeColor = System.Drawing.Color.White;
            this.Pomerit.Location = new System.Drawing.Point(683, 163);
            this.Pomerit.Name = "Pomerit";
            this.Pomerit.PressedDepth = 0;
            this.Pomerit.Size = new System.Drawing.Size(288, 60);
            this.Pomerit.TabIndex = 166;
            this.Pomerit.TabStop = false;
            this.Pomerit.Text = "Poměřit";
            this.Pomerit.TextOffset = new System.Drawing.Point(2, 0);
            this.Pomerit.Visible = false;
            this.Pomerit.Click += new System.EventHandler(this.Pomerit_Click);
            // 
            // VyberZaznamu
            // 
            this.VyberZaznamu.AutoScroll = true;
            this.VyberZaznamu.BorderColor = System.Drawing.Color.Black;
            this.VyberZaznamu.BorderRadius = 20;
            this.VyberZaznamu.Controls.Add(this.PredlohaVyberuHistorie);
            this.VyberZaznamu.Location = new System.Drawing.Point(12, 16);
            this.VyberZaznamu.Name = "VyberZaznamu";
            this.VyberZaznamu.Size = new System.Drawing.Size(620, 400);
            this.VyberZaznamu.TabIndex = 0;
            // 
            // PredlohaVyberuHistorie
            // 
            this.PredlohaVyberuHistorie.Animated = true;
            this.PredlohaVyberuHistorie.AutoRoundedCorners = true;
            this.PredlohaVyberuHistorie.BackColor = System.Drawing.Color.Transparent;
            this.PredlohaVyberuHistorie.BorderRadius = 49;
            this.PredlohaVyberuHistorie.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PredlohaVyberuHistorie.CustomBorderColor = System.Drawing.Color.White;
            this.PredlohaVyberuHistorie.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.PredlohaVyberuHistorie.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.PredlohaVyberuHistorie.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.PredlohaVyberuHistorie.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.PredlohaVyberuHistorie.FillColor = System.Drawing.Color.Gray;
            this.PredlohaVyberuHistorie.Font = new System.Drawing.Font("Arial Black", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World);
            this.PredlohaVyberuHistorie.ForeColor = System.Drawing.Color.White;
            this.PredlohaVyberuHistorie.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.PredlohaVyberuHistorie.HoverState.CustomBorderColor = System.Drawing.Color.Transparent;
            this.PredlohaVyberuHistorie.HoverState.FillColor = System.Drawing.Color.White;
            this.PredlohaVyberuHistorie.HoverState.ForeColor = System.Drawing.Color.Gray;
            this.PredlohaVyberuHistorie.Location = new System.Drawing.Point(100, -80);
            this.PredlohaVyberuHistorie.Name = "PredlohaVyberuHistorie";
            this.PredlohaVyberuHistorie.PressedDepth = 0;
            this.PredlohaVyberuHistorie.Size = new System.Drawing.Size(430, 100);
            this.PredlohaVyberuHistorie.TabIndex = 166;
            this.PredlohaVyberuHistorie.TabStop = false;
            this.PredlohaVyberuHistorie.Text = "Pokus: Tento";
            this.PredlohaVyberuHistorie.TextOffset = new System.Drawing.Point(2, 0);
            this.PredlohaVyberuHistorie.Visible = false;
            // 
            // UkazaniGrafuZaznam
            // 
            this.UkazaniGrafuZaznam.Controls.Add(this.Legenda);
            this.UkazaniGrafuZaznam.Controls.Add(this.panel1);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerCas7);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerCas6);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerCas5);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerCas4);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerCas3);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerCas2);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerCas1);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerGraf7);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerGraf1);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerGraf6);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerGraf5);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerGraf4);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerGraf3);
            this.UkazaniGrafuZaznam.Controls.Add(this.MainPomerGraf2);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerCas7);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerCas6);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerCas5);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerCas4);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerCas3);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerCas2);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerCas1);
            this.UkazaniGrafuZaznam.Controls.Add(this.JmenoHistorie);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerPrumernyCas);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerGraf7);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerGraf1);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerGraf6);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerGraf5);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerGraf4);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerGraf3);
            this.UkazaniGrafuZaznam.Controls.Add(this.PomerGraf2);
            this.UkazaniGrafuZaznam.Location = new System.Drawing.Point(0, 84);
            this.UkazaniGrafuZaznam.Name = "UkazaniGrafuZaznam";
            this.UkazaniGrafuZaznam.Size = new System.Drawing.Size(1000, 420);
            this.UkazaniGrafuZaznam.TabIndex = 170;
            this.UkazaniGrafuZaznam.Visible = false;
            // 
            // Legenda
            // 
            this.Legenda.Controls.Add(this.label8);
            this.Legenda.Controls.Add(this.label7);
            this.Legenda.Location = new System.Drawing.Point(779, 8);
            this.Legenda.Name = "Legenda";
            this.Legenda.Size = new System.Drawing.Size(209, 80);
            this.Legenda.TabIndex = 203;
            this.Legenda.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label8.Location = new System.Drawing.Point(12, 38);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(185, 32);
            this.label8.TabIndex = 205;
            this.label8.Text = "Vybraný Graf";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label7.Location = new System.Drawing.Point(11, 6);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(186, 32);
            this.label7.TabIndex = 204;
            this.label7.Text = "Aktualní Graf";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label11);
            this.panel1.ForeColor = System.Drawing.Color.Transparent;
            this.panel1.Location = new System.Drawing.Point(-24, 381);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1025, 42);
            this.panel1.TabIndex = 165;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label14.Location = new System.Drawing.Point(494, 7);
            this.label14.Margin = new System.Windows.Forms.Padding(0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 32);
            this.label14.TabIndex = 173;
            this.label14.Text = "Ř 4";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label16.Location = new System.Drawing.Point(242, 7);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 32);
            this.label16.TabIndex = 166;
            this.label16.Text = "Ř 2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label9.Location = new System.Drawing.Point(872, 7);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 32);
            this.label9.TabIndex = 185;
            this.label9.Text = "Ř 7";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label15.Location = new System.Drawing.Point(115, 7);
            this.label15.Margin = new System.Windows.Forms.Padding(0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 32);
            this.label15.TabIndex = 167;
            this.label15.Text = "Ř 1";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label10.Location = new System.Drawing.Point(619, 7);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 32);
            this.label10.TabIndex = 176;
            this.label10.Text = "Ř 5";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label13.Location = new System.Drawing.Point(369, 7);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 32);
            this.label13.TabIndex = 174;
            this.label13.Text = "Ř 3";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label11.Location = new System.Drawing.Point(747, 7);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 32);
            this.label11.TabIndex = 175;
            this.label11.Text = "Ř 6";
            // 
            // MainPomerCas7
            // 
            this.MainPomerCas7.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerCas7.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainPomerCas7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerCas7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MainPomerCas7.Location = new System.Drawing.Point(834, 90);
            this.MainPomerCas7.Margin = new System.Windows.Forms.Padding(0);
            this.MainPomerCas7.Name = "MainPomerCas7";
            this.MainPomerCas7.Size = new System.Drawing.Size(88, 32);
            this.MainPomerCas7.TabIndex = 202;
            this.MainPomerCas7.Text = "1000s";
            this.MainPomerCas7.Visible = false;
            // 
            // MainPomerCas6
            // 
            this.MainPomerCas6.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerCas6.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainPomerCas6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerCas6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MainPomerCas6.Location = new System.Drawing.Point(708, 90);
            this.MainPomerCas6.Margin = new System.Windows.Forms.Padding(0);
            this.MainPomerCas6.Name = "MainPomerCas6";
            this.MainPomerCas6.Size = new System.Drawing.Size(88, 32);
            this.MainPomerCas6.TabIndex = 200;
            this.MainPomerCas6.Text = "1000s";
            this.MainPomerCas6.Visible = false;
            // 
            // MainPomerCas5
            // 
            this.MainPomerCas5.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerCas5.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainPomerCas5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerCas5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MainPomerCas5.Location = new System.Drawing.Point(581, 90);
            this.MainPomerCas5.Margin = new System.Windows.Forms.Padding(0);
            this.MainPomerCas5.Name = "MainPomerCas5";
            this.MainPomerCas5.Size = new System.Drawing.Size(88, 32);
            this.MainPomerCas5.TabIndex = 199;
            this.MainPomerCas5.Text = "1000s";
            this.MainPomerCas5.Visible = false;
            // 
            // MainPomerCas4
            // 
            this.MainPomerCas4.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerCas4.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainPomerCas4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerCas4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MainPomerCas4.Location = new System.Drawing.Point(456, 90);
            this.MainPomerCas4.Margin = new System.Windows.Forms.Padding(0);
            this.MainPomerCas4.Name = "MainPomerCas4";
            this.MainPomerCas4.Size = new System.Drawing.Size(88, 32);
            this.MainPomerCas4.TabIndex = 198;
            this.MainPomerCas4.Text = "1000s";
            this.MainPomerCas4.Visible = false;
            // 
            // MainPomerCas3
            // 
            this.MainPomerCas3.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerCas3.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainPomerCas3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerCas3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MainPomerCas3.Location = new System.Drawing.Point(331, 90);
            this.MainPomerCas3.Margin = new System.Windows.Forms.Padding(0);
            this.MainPomerCas3.Name = "MainPomerCas3";
            this.MainPomerCas3.Size = new System.Drawing.Size(88, 32);
            this.MainPomerCas3.TabIndex = 197;
            this.MainPomerCas3.Text = "1000s";
            this.MainPomerCas3.Visible = false;
            // 
            // MainPomerCas2
            // 
            this.MainPomerCas2.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerCas2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainPomerCas2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerCas2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MainPomerCas2.Location = new System.Drawing.Point(205, 90);
            this.MainPomerCas2.Margin = new System.Windows.Forms.Padding(0);
            this.MainPomerCas2.Name = "MainPomerCas2";
            this.MainPomerCas2.Size = new System.Drawing.Size(88, 32);
            this.MainPomerCas2.TabIndex = 196;
            this.MainPomerCas2.Text = "1000s";
            this.MainPomerCas2.Visible = false;
            // 
            // MainPomerCas1
            // 
            this.MainPomerCas1.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerCas1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.MainPomerCas1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerCas1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.MainPomerCas1.Location = new System.Drawing.Point(76, 90);
            this.MainPomerCas1.Margin = new System.Windows.Forms.Padding(0);
            this.MainPomerCas1.Name = "MainPomerCas1";
            this.MainPomerCas1.Size = new System.Drawing.Size(88, 32);
            this.MainPomerCas1.TabIndex = 195;
            this.MainPomerCas1.Text = "1000s";
            this.MainPomerCas1.Visible = false;
            // 
            // MainPomerGraf7
            // 
            this.MainPomerGraf7.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerGraf7.BorderRadius = 20;
            this.MainPomerGraf7.Cursor = System.Windows.Forms.Cursors.Help;
            this.MainPomerGraf7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerGraf7.ImageRotate = 0F;
            this.MainPomerGraf7.Location = new System.Drawing.Point(866, 338);
            this.MainPomerGraf7.Name = "MainPomerGraf7";
            this.MainPomerGraf7.Size = new System.Drawing.Size(46, 72);
            this.MainPomerGraf7.TabIndex = 201;
            this.MainPomerGraf7.TabStop = false;
            this.MainPomerGraf7.UseTransparentBackground = true;
            this.MainPomerGraf7.Visible = false;
            // 
            // MainPomerGraf1
            // 
            this.MainPomerGraf1.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerGraf1.BorderRadius = 20;
            this.MainPomerGraf1.Cursor = System.Windows.Forms.Cursors.Help;
            this.MainPomerGraf1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerGraf1.ImageRotate = 0F;
            this.MainPomerGraf1.Location = new System.Drawing.Point(108, 328);
            this.MainPomerGraf1.Name = "MainPomerGraf1";
            this.MainPomerGraf1.Size = new System.Drawing.Size(46, 72);
            this.MainPomerGraf1.TabIndex = 194;
            this.MainPomerGraf1.TabStop = false;
            this.MainPomerGraf1.UseTransparentBackground = true;
            this.MainPomerGraf1.Visible = false;
            // 
            // MainPomerGraf6
            // 
            this.MainPomerGraf6.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerGraf6.BorderRadius = 20;
            this.MainPomerGraf6.Cursor = System.Windows.Forms.Cursors.Help;
            this.MainPomerGraf6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerGraf6.ImageRotate = 0F;
            this.MainPomerGraf6.Location = new System.Drawing.Point(740, 338);
            this.MainPomerGraf6.Name = "MainPomerGraf6";
            this.MainPomerGraf6.Size = new System.Drawing.Size(46, 72);
            this.MainPomerGraf6.TabIndex = 193;
            this.MainPomerGraf6.TabStop = false;
            this.MainPomerGraf6.UseTransparentBackground = true;
            this.MainPomerGraf6.Visible = false;
            // 
            // MainPomerGraf5
            // 
            this.MainPomerGraf5.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerGraf5.BorderRadius = 20;
            this.MainPomerGraf5.Cursor = System.Windows.Forms.Cursors.Help;
            this.MainPomerGraf5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerGraf5.ImageRotate = 0F;
            this.MainPomerGraf5.Location = new System.Drawing.Point(613, 338);
            this.MainPomerGraf5.Name = "MainPomerGraf5";
            this.MainPomerGraf5.Size = new System.Drawing.Size(46, 72);
            this.MainPomerGraf5.TabIndex = 192;
            this.MainPomerGraf5.TabStop = false;
            this.MainPomerGraf5.UseTransparentBackground = true;
            this.MainPomerGraf5.Visible = false;
            // 
            // MainPomerGraf4
            // 
            this.MainPomerGraf4.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerGraf4.BorderRadius = 20;
            this.MainPomerGraf4.Cursor = System.Windows.Forms.Cursors.Help;
            this.MainPomerGraf4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerGraf4.ImageRotate = 0F;
            this.MainPomerGraf4.Location = new System.Drawing.Point(488, 361);
            this.MainPomerGraf4.Name = "MainPomerGraf4";
            this.MainPomerGraf4.Size = new System.Drawing.Size(46, 72);
            this.MainPomerGraf4.TabIndex = 191;
            this.MainPomerGraf4.TabStop = false;
            this.MainPomerGraf4.UseTransparentBackground = true;
            this.MainPomerGraf4.Visible = false;
            // 
            // MainPomerGraf3
            // 
            this.MainPomerGraf3.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerGraf3.BorderRadius = 20;
            this.MainPomerGraf3.Cursor = System.Windows.Forms.Cursors.Help;
            this.MainPomerGraf3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerGraf3.ImageRotate = 0F;
            this.MainPomerGraf3.Location = new System.Drawing.Point(362, 338);
            this.MainPomerGraf3.Name = "MainPomerGraf3";
            this.MainPomerGraf3.Size = new System.Drawing.Size(46, 72);
            this.MainPomerGraf3.TabIndex = 190;
            this.MainPomerGraf3.TabStop = false;
            this.MainPomerGraf3.UseTransparentBackground = true;
            this.MainPomerGraf3.Visible = false;
            // 
            // MainPomerGraf2
            // 
            this.MainPomerGraf2.BackColor = System.Drawing.Color.Transparent;
            this.MainPomerGraf2.BorderRadius = 20;
            this.MainPomerGraf2.Cursor = System.Windows.Forms.Cursors.Help;
            this.MainPomerGraf2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.MainPomerGraf2.ImageRotate = 0F;
            this.MainPomerGraf2.Location = new System.Drawing.Point(237, 338);
            this.MainPomerGraf2.Name = "MainPomerGraf2";
            this.MainPomerGraf2.Size = new System.Drawing.Size(46, 72);
            this.MainPomerGraf2.TabIndex = 189;
            this.MainPomerGraf2.TabStop = false;
            this.MainPomerGraf2.UseTransparentBackground = true;
            this.MainPomerGraf2.Visible = false;
            // 
            // PomerCas7
            // 
            this.PomerCas7.BackColor = System.Drawing.Color.Transparent;
            this.PomerCas7.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PomerCas7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerCas7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PomerCas7.Location = new System.Drawing.Point(834, 122);
            this.PomerCas7.Margin = new System.Windows.Forms.Padding(0);
            this.PomerCas7.Name = "PomerCas7";
            this.PomerCas7.Size = new System.Drawing.Size(88, 32);
            this.PomerCas7.TabIndex = 186;
            this.PomerCas7.Text = "1000s";
            // 
            // PomerCas6
            // 
            this.PomerCas6.BackColor = System.Drawing.Color.Transparent;
            this.PomerCas6.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PomerCas6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerCas6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PomerCas6.Location = new System.Drawing.Point(708, 122);
            this.PomerCas6.Margin = new System.Windows.Forms.Padding(0);
            this.PomerCas6.Name = "PomerCas6";
            this.PomerCas6.Size = new System.Drawing.Size(88, 32);
            this.PomerCas6.TabIndex = 183;
            this.PomerCas6.Text = "1000s";
            // 
            // PomerCas5
            // 
            this.PomerCas5.BackColor = System.Drawing.Color.Transparent;
            this.PomerCas5.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PomerCas5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerCas5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PomerCas5.Location = new System.Drawing.Point(581, 122);
            this.PomerCas5.Margin = new System.Windows.Forms.Padding(0);
            this.PomerCas5.Name = "PomerCas5";
            this.PomerCas5.Size = new System.Drawing.Size(88, 32);
            this.PomerCas5.TabIndex = 182;
            this.PomerCas5.Text = "1000s";
            // 
            // PomerCas4
            // 
            this.PomerCas4.BackColor = System.Drawing.Color.Transparent;
            this.PomerCas4.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PomerCas4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerCas4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PomerCas4.Location = new System.Drawing.Point(456, 122);
            this.PomerCas4.Margin = new System.Windows.Forms.Padding(0);
            this.PomerCas4.Name = "PomerCas4";
            this.PomerCas4.Size = new System.Drawing.Size(88, 32);
            this.PomerCas4.TabIndex = 181;
            this.PomerCas4.Text = "1000s";
            // 
            // PomerCas3
            // 
            this.PomerCas3.BackColor = System.Drawing.Color.Transparent;
            this.PomerCas3.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PomerCas3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerCas3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PomerCas3.Location = new System.Drawing.Point(331, 122);
            this.PomerCas3.Margin = new System.Windows.Forms.Padding(0);
            this.PomerCas3.Name = "PomerCas3";
            this.PomerCas3.Size = new System.Drawing.Size(88, 32);
            this.PomerCas3.TabIndex = 180;
            this.PomerCas3.Text = "1000s";
            // 
            // PomerCas2
            // 
            this.PomerCas2.BackColor = System.Drawing.Color.Transparent;
            this.PomerCas2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PomerCas2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerCas2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PomerCas2.Location = new System.Drawing.Point(205, 122);
            this.PomerCas2.Margin = new System.Windows.Forms.Padding(0);
            this.PomerCas2.Name = "PomerCas2";
            this.PomerCas2.Size = new System.Drawing.Size(88, 32);
            this.PomerCas2.TabIndex = 179;
            this.PomerCas2.Text = "1000s";
            // 
            // PomerCas1
            // 
            this.PomerCas1.BackColor = System.Drawing.Color.Transparent;
            this.PomerCas1.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.PomerCas1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerCas1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PomerCas1.Location = new System.Drawing.Point(76, 122);
            this.PomerCas1.Margin = new System.Windows.Forms.Padding(0);
            this.PomerCas1.Name = "PomerCas1";
            this.PomerCas1.Size = new System.Drawing.Size(88, 32);
            this.PomerCas1.TabIndex = 178;
            this.PomerCas1.Text = "1000s";
            // 
            // JmenoHistorie
            // 
            this.JmenoHistorie.AutoSize = true;
            this.JmenoHistorie.Font = new System.Drawing.Font("Arial Black", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.JmenoHistorie.ForeColor = System.Drawing.Color.Gray;
            this.JmenoHistorie.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.JmenoHistorie.Location = new System.Drawing.Point(12, 3);
            this.JmenoHistorie.Margin = new System.Windows.Forms.Padding(0);
            this.JmenoHistorie.Name = "JmenoHistorie";
            this.JmenoHistorie.Size = new System.Drawing.Size(201, 48);
            this.JmenoHistorie.TabIndex = 187;
            this.JmenoHistorie.Text = "Historie 1";
            // 
            // PomerPrumernyCas
            // 
            this.PomerPrumernyCas.Font = new System.Drawing.Font("Arial Black", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.PomerPrumernyCas.ForeColor = System.Drawing.Color.White;
            this.PomerPrumernyCas.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.PomerPrumernyCas.Location = new System.Drawing.Point(213, 7);
            this.PomerPrumernyCas.Margin = new System.Windows.Forms.Padding(0);
            this.PomerPrumernyCas.Name = "PomerPrumernyCas";
            this.PomerPrumernyCas.Size = new System.Drawing.Size(563, 37);
            this.PomerPrumernyCas.TabIndex = 187;
            this.PomerPrumernyCas.Text = "10";
            this.PomerPrumernyCas.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // PomerGraf7
            // 
            this.PomerGraf7.BackColor = System.Drawing.Color.Transparent;
            this.PomerGraf7.BorderRadius = 20;
            this.PomerGraf7.Cursor = System.Windows.Forms.Cursors.Help;
            this.PomerGraf7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerGraf7.ImageRotate = 0F;
            this.PomerGraf7.Location = new System.Drawing.Point(840, 328);
            this.PomerGraf7.Name = "PomerGraf7";
            this.PomerGraf7.Size = new System.Drawing.Size(46, 72);
            this.PomerGraf7.TabIndex = 184;
            this.PomerGraf7.TabStop = false;
            this.PomerGraf7.UseTransparentBackground = true;
            // 
            // PomerGraf1
            // 
            this.PomerGraf1.BackColor = System.Drawing.Color.Transparent;
            this.PomerGraf1.BorderRadius = 20;
            this.PomerGraf1.Cursor = System.Windows.Forms.Cursors.Help;
            this.PomerGraf1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerGraf1.ImageRotate = 0F;
            this.PomerGraf1.Location = new System.Drawing.Point(82, 318);
            this.PomerGraf1.Name = "PomerGraf1";
            this.PomerGraf1.Size = new System.Drawing.Size(46, 72);
            this.PomerGraf1.TabIndex = 177;
            this.PomerGraf1.TabStop = false;
            this.PomerGraf1.UseTransparentBackground = true;
            // 
            // PomerGraf6
            // 
            this.PomerGraf6.BackColor = System.Drawing.Color.Transparent;
            this.PomerGraf6.BorderRadius = 20;
            this.PomerGraf6.Cursor = System.Windows.Forms.Cursors.Help;
            this.PomerGraf6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerGraf6.ImageRotate = 0F;
            this.PomerGraf6.Location = new System.Drawing.Point(714, 328);
            this.PomerGraf6.Name = "PomerGraf6";
            this.PomerGraf6.Size = new System.Drawing.Size(46, 72);
            this.PomerGraf6.TabIndex = 172;
            this.PomerGraf6.TabStop = false;
            this.PomerGraf6.UseTransparentBackground = true;
            // 
            // PomerGraf5
            // 
            this.PomerGraf5.BackColor = System.Drawing.Color.Transparent;
            this.PomerGraf5.BorderRadius = 20;
            this.PomerGraf5.Cursor = System.Windows.Forms.Cursors.Help;
            this.PomerGraf5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerGraf5.ImageRotate = 0F;
            this.PomerGraf5.Location = new System.Drawing.Point(587, 328);
            this.PomerGraf5.Name = "PomerGraf5";
            this.PomerGraf5.Size = new System.Drawing.Size(46, 72);
            this.PomerGraf5.TabIndex = 171;
            this.PomerGraf5.TabStop = false;
            this.PomerGraf5.UseTransparentBackground = true;
            // 
            // PomerGraf4
            // 
            this.PomerGraf4.BackColor = System.Drawing.Color.Transparent;
            this.PomerGraf4.BorderRadius = 20;
            this.PomerGraf4.Cursor = System.Windows.Forms.Cursors.Help;
            this.PomerGraf4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerGraf4.ImageRotate = 0F;
            this.PomerGraf4.Location = new System.Drawing.Point(462, 351);
            this.PomerGraf4.Name = "PomerGraf4";
            this.PomerGraf4.Size = new System.Drawing.Size(46, 72);
            this.PomerGraf4.TabIndex = 170;
            this.PomerGraf4.TabStop = false;
            this.PomerGraf4.UseTransparentBackground = true;
            // 
            // PomerGraf3
            // 
            this.PomerGraf3.BackColor = System.Drawing.Color.Transparent;
            this.PomerGraf3.BorderRadius = 20;
            this.PomerGraf3.Cursor = System.Windows.Forms.Cursors.Help;
            this.PomerGraf3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerGraf3.ImageRotate = 0F;
            this.PomerGraf3.Location = new System.Drawing.Point(336, 328);
            this.PomerGraf3.Name = "PomerGraf3";
            this.PomerGraf3.Size = new System.Drawing.Size(46, 72);
            this.PomerGraf3.TabIndex = 169;
            this.PomerGraf3.TabStop = false;
            this.PomerGraf3.UseTransparentBackground = true;
            // 
            // PomerGraf2
            // 
            this.PomerGraf2.BackColor = System.Drawing.Color.Transparent;
            this.PomerGraf2.BorderRadius = 20;
            this.PomerGraf2.Cursor = System.Windows.Forms.Cursors.Help;
            this.PomerGraf2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.PomerGraf2.ImageRotate = 0F;
            this.PomerGraf2.Location = new System.Drawing.Point(211, 328);
            this.PomerGraf2.Name = "PomerGraf2";
            this.PomerGraf2.Size = new System.Drawing.Size(46, 72);
            this.PomerGraf2.TabIndex = 168;
            this.PomerGraf2.TabStop = false;
            this.PomerGraf2.UseTransparentBackground = true;
            // 
            // EndingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(1000, 504);
            this.Controls.Add(this.MovingPanel);
            this.Controls.Add(this.UkazaniGrafuZaznam);
            this.Controls.Add(this.HistoryPanel);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FullTime);
            this.Controls.Add(this.T7);
            this.Controls.Add(this.T6);
            this.Controls.Add(this.T5);
            this.Controls.Add(this.T4);
            this.Controls.Add(this.T3);
            this.Controls.Add(this.T2);
            this.Controls.Add(this.T1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.G7);
            this.Controls.Add(this.G1);
            this.Controls.Add(this.G6);
            this.Controls.Add(this.G5);
            this.Controls.Add(this.G4);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.G2);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EndingForm";
            this.Text = "Skore";
            this.Load += new System.EventHandler(this.EndingForm_Load);
            this.MovingPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.G3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.G1)).EndInit();
            this.HistoryPanel.ResumeLayout(false);
            this.HistoryPanel.PerformLayout();
            this.VyberZaznamu.ResumeLayout(false);
            this.UkazaniGrafuZaznam.ResumeLayout(false);
            this.UkazaniGrafuZaznam.PerformLayout();
            this.Legenda.ResumeLayout(false);
            this.Legenda.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MainPomerGraf2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PomerGraf2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public Guna.UI2.WinForms.Guna2CircleButton Close;
        public Guna.UI2.WinForms.Guna2CustomGradientPanel MovingPanel;
        public System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public Guna.UI2.WinForms.Guna2PictureBox G3;
        public Guna.UI2.WinForms.Guna2PictureBox G4;
        public Guna.UI2.WinForms.Guna2PictureBox G5;
        public Guna.UI2.WinForms.Guna2PictureBox G6;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label T1;
        public System.Windows.Forms.Label T2;
        public System.Windows.Forms.Label T3;
        public System.Windows.Forms.Label T4;
        public System.Windows.Forms.Label T5;
        public System.Windows.Forms.Label T6;
        public Guna.UI2.WinForms.Guna2PictureBox G7;
        public System.Windows.Forms.Label label12;
        public System.Windows.Forms.Label T7;
        public System.Windows.Forms.Label FullTime;
        public Guna.UI2.WinForms.Guna2PictureBox G2;
        public Guna.UI2.WinForms.Guna2PictureBox G1;
        private Guna.UI2.WinForms.Guna2Button History;
        private Guna.UI2.WinForms.Guna2Panel HistoryPanel;
        private Guna.UI2.WinForms.Guna2Panel VyberZaznamu;
        private Guna.UI2.WinForms.Guna2Button PredlohaVyberuHistorie;
        private Guna.UI2.WinForms.Guna2Button Pomerit;
        private System.Windows.Forms.Label PodtextUkazatGraf;
        private Guna.UI2.WinForms.Guna2Button Ukazatgraf;
        private System.Windows.Forms.Label PodtextPomerit;
        private Guna.UI2.WinForms.Guna2Panel UkazaniGrafuZaznam;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label13;
        public System.Windows.Forms.Label label14;
        public System.Windows.Forms.Label label15;
        public System.Windows.Forms.Label label16;
        public System.Windows.Forms.Label PomerCas7;
        public System.Windows.Forms.Label PomerCas6;
        public System.Windows.Forms.Label PomerCas5;
        public System.Windows.Forms.Label PomerCas4;
        public System.Windows.Forms.Label PomerCas3;
        public System.Windows.Forms.Label PomerCas2;
        public System.Windows.Forms.Label PomerCas1;
        public System.Windows.Forms.Panel panel1;
        public Guna.UI2.WinForms.Guna2PictureBox PomerGraf7;
        public Guna.UI2.WinForms.Guna2PictureBox PomerGraf1;
        public Guna.UI2.WinForms.Guna2PictureBox PomerGraf6;
        public Guna.UI2.WinForms.Guna2PictureBox PomerGraf5;
        public Guna.UI2.WinForms.Guna2PictureBox PomerGraf4;
        public Guna.UI2.WinForms.Guna2PictureBox PomerGraf3;
        public Guna.UI2.WinForms.Guna2PictureBox PomerGraf2;
        public System.Windows.Forms.Label JmenoHistorie;
        public System.Windows.Forms.Label PomerPrumernyCas;
        public System.Windows.Forms.Label UkazatelVyberu;
        public System.Windows.Forms.Label MainPomerCas7;
        public System.Windows.Forms.Label MainPomerCas6;
        public System.Windows.Forms.Label MainPomerCas5;
        public System.Windows.Forms.Label MainPomerCas4;
        public System.Windows.Forms.Label MainPomerCas3;
        public System.Windows.Forms.Label MainPomerCas2;
        public System.Windows.Forms.Label MainPomerCas1;
        public Guna.UI2.WinForms.Guna2PictureBox MainPomerGraf7;
        public Guna.UI2.WinForms.Guna2PictureBox MainPomerGraf1;
        public Guna.UI2.WinForms.Guna2PictureBox MainPomerGraf6;
        public Guna.UI2.WinForms.Guna2PictureBox MainPomerGraf5;
        public Guna.UI2.WinForms.Guna2PictureBox MainPomerGraf4;
        public Guna.UI2.WinForms.Guna2PictureBox MainPomerGraf3;
        public Guna.UI2.WinForms.Guna2PictureBox MainPomerGraf2;
        private System.Windows.Forms.Panel Legenda;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label7;
    }
}