﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Binar
{
    public partial class EndingForm : Form
    {
       
        private Point mouseDownLocation;
        public EndingForm()
        {
            InitializeComponent();
            MovingPanel.MouseDown += MovingPanel_MouseDown;
            MovingPanel.MouseMove += MovingPanel_MouseMove;
            MovingPanel.MouseUp += MovingPanel_MouseUp;
        }
        private void MovingPanel_MouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                mouseDownLocation = e.Location;
            }
        }

        private void MovingPanel_MouseMove(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                int deltaX = e.X - mouseDownLocation.X;
                int deltaY = e.Y - mouseDownLocation.Y;
                this.Location = new Point(this.Location.X + deltaX, this.Location.Y + deltaY);
            }
        }

        private void MovingPanel_MouseUp(object sender, MouseEventArgs e)
        {

            mouseDownLocation = Point.Empty;
        }
        int line1Value = 0;
        int line2Value = 0;
        int line3Value = 0;
        int line4Value = 0;
        int line5Value = 0;
        int line6Value = 0;
        int line7Value = 0;
        private void UkazatGraf_Click(object sender, EventArgs e)
        {
            HistoryPanel.Visible = false;
            UkazaniGrafuZaznam.Visible = true;
            Legenda.Visible = false;

            MainPomerGraf1.Visible = false;
            MainPomerGraf2.Visible = false;
            MainPomerGraf3.Visible = false;
            MainPomerGraf4.Visible = false;
            MainPomerGraf5.Visible = false;
            MainPomerGraf6.Visible = false;
            MainPomerGraf7.Visible = false;

            MainPomerCas1.Visible = false;
            MainPomerCas2.Visible = false;
            MainPomerCas3.Visible = false;
            MainPomerCas4.Visible = false;
            MainPomerCas5.Visible = false;
            MainPomerCas6.Visible = false;
            MainPomerCas7.Visible = false;


            int maxValue = Math.Max(line1Value, Math.Max(line2Value, Math.Max(line3Value, Math.Max(line4Value, Math.Max(line5Value, Math.Max(line6Value, line7Value))))));



            PomerGraf1.Height = 250 * line1Value / maxValue;
            PomerGraf2.Height = 250 * line2Value / maxValue;
            PomerGraf3.Height = 250 * line3Value / maxValue;
            PomerGraf4.Height = 250 * line4Value / maxValue;
            PomerGraf5.Height = 250 * line5Value / maxValue;
            PomerGraf6.Height = 250 * line6Value / maxValue;
            PomerGraf7.Height = 250 * line7Value / maxValue;


            PomerGraf1.Location = new Point(PomerGraf1.Location.X, 415 - (250 * line1Value / maxValue));
            PomerGraf2.Location = new Point(PomerGraf2.Location.X, 415 - (250 * line2Value / maxValue));
            PomerGraf3.Location = new Point(PomerGraf3.Location.X, 415 - (250 * line3Value / maxValue));
            PomerGraf4.Location = new Point(PomerGraf4.Location.X, 415 - (250 * line4Value / maxValue));
            PomerGraf5.Location = new Point(PomerGraf5.Location.X, 415 - (250 * line5Value / maxValue));
            PomerGraf6.Location = new Point(PomerGraf6.Location.X, 415 - (250 * line6Value / maxValue));
            PomerGraf7.Location = new Point(PomerGraf7.Location.X, 415 - (250 * line7Value / maxValue));


            //PomerCas1.Location = new Point(PomerGraf1.Right -  PomerCas1.Width * 1, PomerGraf1.Top - PomerCas1.Height * 1);
            //PomerCas2.Location = new Point(PomerGraf2.Right - PomerCas2.Width * 1, PomerGraf2.Top - PomerCas2.Height * 1);
            //PomerCas3.Location = new Point(PomerGraf3.Right - PomerCas3.Width * 1, PomerGraf3.Top - PomerCas3.Height * 1);
            //PomerCas4.Location = new Point(PomerGraf4.Right - PomerCas4.Width * 1, PomerGraf4.Top - PomerCas4.Height * 1);
            //PomerCas5.Location = new Point(PomerGraf5.Right - PomerCas5.Width * 1, PomerGraf5.Top - PomerCas5.Height * 1);
            //PomerCas6.Location = new Point(PomerGraf6.Right - PomerCas6.Width * 1, PomerGraf6.Top - PomerCas6.Height * 1);
            //PomerCas7.Location = new Point(PomerGraf7.Right - PomerCas7.Width * 1, PomerGraf7.Top - PomerCas7.Height * 1);


            PomerCas1.Text = line1Value + "s";
            PomerCas2.Text = line2Value + "s";
            PomerCas3.Text = line3Value + "s";
            PomerCas4.Text = line4Value + "s";
            PomerCas5.Text = line5Value + "s";
            PomerCas6.Text = line6Value + "s";
            PomerCas7.Text = line7Value + "s";


            int averageTime = (line1Value + line2Value + line3Value + line4Value + line5Value + line6Value + line7Value) / 7;


            PomerPrumernyCas.Text = "Průměrný Čas: " + averageTime.ToString() + "s";


        }
        private void Pomerit_Click(object sender, EventArgs e)
        {
            HistoryPanel.Visible = false;
            UkazaniGrafuZaznam.Visible = true;
            Legenda.Visible = true;

            MainPomerGraf1.Visible = true;
            MainPomerGraf2.Visible = true;
            MainPomerGraf3.Visible = true;
            MainPomerGraf4.Visible = true;
            MainPomerGraf5.Visible = true;
            MainPomerGraf6.Visible = true;
            MainPomerGraf7.Visible = true;

            MainPomerCas1.Visible = true;
            MainPomerCas2.Visible = true;
            MainPomerCas3.Visible = true;
            MainPomerCas4.Visible = true;
            MainPomerCas5.Visible = true;
            MainPomerCas6.Visible = true;
            MainPomerCas7.Visible = true;


            int maxValue = Math.Max(line1Value, Math.Max(line2Value, Math.Max(line3Value, Math.Max(line4Value, Math.Max(line5Value, Math.Max(line6Value, Math.Max(line7Value, Math.Max(Convert.ToInt32(G1.AccessibleDescription), Math.Max(Convert.ToInt32(G2.AccessibleDescription), Math.Max(Convert.ToInt32(G3.AccessibleDescription), Math.Max(Convert.ToInt32(G4.AccessibleDescription), Math.Max(Convert.ToInt32(G5.AccessibleDescription), Math.Max(Convert.ToInt32(G6.AccessibleDescription), Convert.ToInt32(G7.AccessibleDescription))))))))))))));



            PomerGraf1.Height = 250 * line1Value / maxValue;
            PomerGraf2.Height = 250 * line2Value / maxValue;
            PomerGraf3.Height = 250 * line3Value / maxValue;
            PomerGraf4.Height = 250 * line4Value / maxValue;
            PomerGraf5.Height = 250 * line5Value / maxValue;
            PomerGraf6.Height = 250 * line6Value / maxValue;
            PomerGraf7.Height = 250 * line7Value / maxValue;


            PomerGraf1.Location = new Point(PomerGraf1.Location.X, 415 - (250 * line1Value / maxValue));
            PomerGraf2.Location = new Point(PomerGraf2.Location.X, 415 - (250 * line2Value / maxValue));
            PomerGraf3.Location = new Point(PomerGraf3.Location.X, 415 - (250 * line3Value / maxValue));
            PomerGraf4.Location = new Point(PomerGraf4.Location.X, 415 - (250 * line4Value / maxValue));
            PomerGraf5.Location = new Point(PomerGraf5.Location.X, 415 - (250 * line5Value / maxValue));
            PomerGraf6.Location = new Point(PomerGraf6.Location.X, 415 - (250 * line6Value / maxValue));
            PomerGraf7.Location = new Point(PomerGraf7.Location.X, 415 - (250 * line7Value / maxValue));


            //PomerCas1.Location = new Point(PomerGraf1.Right - PomerCas1.Width * 1, PomerGraf1.Top - PomerCas1.Height * 1);
            //PomerCas2.Location = new Point(PomerGraf2.Right - PomerCas2.Width * 1, PomerGraf2.Top - PomerCas2.Height * 1);
            //PomerCas3.Location = new Point(PomerGraf3.Right - PomerCas3.Width * 1, PomerGraf3.Top - PomerCas3.Height * 1);
            //PomerCas4.Location = new Point(PomerGraf4.Right - PomerCas4.Width * 1, PomerGraf4.Top - PomerCas4.Height * 1);
            //PomerCas5.Location = new Point(PomerGraf5.Right - PomerCas5.Width * 1, PomerGraf5.Top - PomerCas5.Height * 1);
            //PomerCas6.Location = new Point(PomerGraf6.Right - PomerCas6.Width * 1, PomerGraf6.Top - PomerCas6.Height * 1);
            //PomerCas7.Location = new Point(PomerGraf7.Right - PomerCas7.Width * 1, PomerGraf7.Top - PomerCas7.Height * 1);


            PomerCas1.Text = line1Value + "s";
            PomerCas2.Text = line2Value + "s";
            PomerCas3.Text = line3Value + "s";
            PomerCas4.Text = line4Value + "s";
            PomerCas5.Text = line5Value + "s";
            PomerCas6.Text = line6Value + "s";
            PomerCas7.Text = line7Value + "s";


            int averageTime = (line1Value + line2Value + line3Value + line4Value + line5Value + line6Value + line7Value) / 7;




            ////////////////////////////////////////////////////////////////////////////////////

            

            MainPomerGraf1.Height = 250 * Convert.ToInt32(G1.AccessibleDescription) / maxValue;
            MainPomerGraf2.Height = 250 * Convert.ToInt32(G2.AccessibleDescription) / maxValue;
            MainPomerGraf3.Height = 250 * Convert.ToInt32(G3.AccessibleDescription) / maxValue;
            MainPomerGraf4.Height = 250 * Convert.ToInt32(G4.AccessibleDescription) / maxValue;
            MainPomerGraf5.Height = 250 * Convert.ToInt32(G5.AccessibleDescription) / maxValue;
            MainPomerGraf6.Height = 250 * Convert.ToInt32(G6.AccessibleDescription) / maxValue;
            MainPomerGraf7.Height = 250 * Convert.ToInt32(G7.AccessibleDescription) / maxValue;


            MainPomerGraf1.Location = new Point(MainPomerGraf1.Location.X, 415 - (250 * Convert.ToInt32(G1.AccessibleDescription) / maxValue));
            MainPomerGraf2.Location = new Point(MainPomerGraf2.Location.X, 415 - (250 * Convert.ToInt32(G2.AccessibleDescription) / maxValue));
            MainPomerGraf3.Location = new Point(MainPomerGraf3.Location.X, 415 - (250 * Convert.ToInt32(G3.AccessibleDescription) / maxValue));
            MainPomerGraf4.Location = new Point(MainPomerGraf4.Location.X, 415 - (250 * Convert.ToInt32(G4.AccessibleDescription) / maxValue));
            MainPomerGraf5.Location = new Point(MainPomerGraf5.Location.X, 415 - (250 * Convert.ToInt32(G5.AccessibleDescription) / maxValue));
            MainPomerGraf6.Location = new Point(MainPomerGraf6.Location.X, 415 - (250 * Convert.ToInt32(G6.AccessibleDescription) / maxValue));
            MainPomerGraf7.Location = new Point(MainPomerGraf7.Location.X, 415 - (250 * Convert.ToInt32(G7.AccessibleDescription) / maxValue));


            //MainPomerCas1.Location = new Point(MainPomerGraf1.Right - MainPomerCas1.Width * 1, MainPomerGraf1.Top - MainPomerCas1.Height * 1);
            //MainPomerCas2.Location = new Point(MainPomerGraf2.Right - MainPomerCas2.Width * 1, MainPomerGraf2.Top - MainPomerCas2.Height * 1);
            //MainPomerCas3.Location = new Point(MainPomerGraf3.Right - MainPomerCas3.Width * 1, MainPomerGraf3.Top - MainPomerCas3.Height * 1);
            //MainPomerCas4.Location = new Point(MainPomerGraf4.Right - MainPomerCas4.Width * 1, MainPomerGraf4.Top - MainPomerCas4.Height * 1);
            //MainPomerCas5.Location = new Point(MainPomerGraf5.Right - MainPomerCas5.Width * 1, MainPomerGraf5.Top - MainPomerCas5.Height * 1);
            //MainPomerCas6.Location = new Point(MainPomerGraf6.Right - MainPomerCas6.Width * 1, MainPomerGraf6.Top - MainPomerCas6.Height * 1);
            //MainPomerCas7.Location = new Point(MainPomerGraf7.Right - MainPomerCas7.Width * 1, MainPomerGraf7.Top - MainPomerCas7.Height * 1);


            MainPomerCas1.Text = Convert.ToInt32(G1.AccessibleDescription) + "s";
            MainPomerCas2.Text = Convert.ToInt32(G2.AccessibleDescription) + "s";
            MainPomerCas3.Text = Convert.ToInt32(G3.AccessibleDescription) + "s";
            MainPomerCas4.Text = Convert.ToInt32(G4.AccessibleDescription) + "s";
            MainPomerCas5.Text = Convert.ToInt32(G5.AccessibleDescription) + "s";
            MainPomerCas6.Text = Convert.ToInt32(G6.AccessibleDescription) + "s";
            MainPomerCas7.Text = Convert.ToInt32(G7.AccessibleDescription) + "s";


            int averageTimeMain = (Convert.ToInt32(G1.AccessibleDescription) + Convert.ToInt32(G2.AccessibleDescription) + Convert.ToInt32(G3.AccessibleDescription) + Convert.ToInt32(G4.AccessibleDescription) + Convert.ToInt32(G5.AccessibleDescription) + Convert.ToInt32(G6.AccessibleDescription) + Convert.ToInt32(G7.AccessibleDescription)) / 7;
            int ZlepseniZhorseni = averageTimeMain - averageTime;
            if (ZlepseniZhorseni < 0)
            {
                PomerPrumernyCas.Text = "Zlepšení času o: " + Math.Abs(ZlepseniZhorseni).ToString() + "s";
            }
            else if (ZlepseniZhorseni > 0)
            {
                PomerPrumernyCas.Text = "Zhoršení času o: " + ZlepseniZhorseni.ToString() + "s";
            }
            else if (ZlepseniZhorseni == 0)
            {
                PomerPrumernyCas.Text = "Není změna času";
            }



        }
        private void HistorieTlacitko_Click(object sender, EventArgs e)
        {
            Guna2Button tlacitko = (Guna2Button)sender;
            if(tlacitko.FillColor == Color.Gray)
            {
                JmenoHistorie.Text = "Pokus: " + tlacitko.Tag;
                UkazatelVyberu.Text = "Pokus: " + tlacitko.Tag;
                Pomerit.Visible = true;
                Ukazatgraf.Visible = true;
                PodtextPomerit.Visible= true;
                PodtextUkazatGraf.Visible= true;
                Dictionary<string, int> historieData;          

            if (Mezipamet.Cache["HlavniHistorie"].TryGetValue(tlacitko.Name, out historieData))
            {

                 line1Value = historieData["Line1"];
                 line2Value = historieData["Line2"];
                 line3Value = historieData["Line3"];
                 line4Value = historieData["Line4"];
                 line5Value = historieData["Line5"];
                 line6Value = historieData["Line6"];
                 line7Value = historieData["Line7"];

                

            }
            else
            {

                Console.WriteLine("Historie1 nebyla nalezena v HlavniHistorie.");
            }

            }
        }
        private void EndingForm_Load(object sender, EventArgs e)
        {
            HistoryPanel.Size = new Size(1000, 436);
            HistoryPanel.Location = new Point(0, 68);
            UkazaniGrafuZaznam.Size = new Size(1000, 436);
            UkazaniGrafuZaznam.Location = new Point(0, 68);


            for (int i = Convert.ToInt32(this.Tag); 1 <= i;)
            {
                

                Guna2Button copyButton = new Guna2Button();
                copyButton.Name = "Historie" + i.ToString();
                copyButton.Tag = i.ToString();
                copyButton.Text = "Pokus: "+(i).ToString();
                copyButton.Size = PredlohaVyberuHistorie.Size;
                copyButton.AutoRoundedCorners = true;
                copyButton.BackColor = Color.Transparent;
                copyButton.Animated = true;
                copyButton.FillColor = Color.Gray;
                copyButton.ForeColor = Color.White;                
                copyButton.HoverState.ForeColor = Color.Gray;
                copyButton.HoverState.FillColor = Color.White;
                copyButton.Font = new Font("Arial Black", 30, FontStyle.Bold);  

                copyButton.Location = new Point(PredlohaVyberuHistorie.Location.X, PredlohaVyberuHistorie.Location.Y + PredlohaVyberuHistorie.Height + Math.Abs(1-i) *140);

                copyButton.Click += new EventHandler(HistorieTlacitko_Click);
                if (i== Convert.ToInt32(this.Tag))
                {
                    copyButton.Text = "Pokus: " + "Aktualní";
                    copyButton.FillColor = Color.Black;
                    copyButton.ForeColor = Color.White;
                    copyButton.HoverState.ForeColor = Color.Black;
                    copyButton.HoverState.FillColor = Color.White;
                    copyButton.Cursor = Cursors.No;
                    }
                VyberZaznamu.Controls.Add(copyButton);

                i--;
            }
         


        }
        private void Close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void History_Click(object sender, EventArgs e)
        {
            if (!HistoryPanel.Visible)
            { 
            HistoryPanel.Visible = true;
            History.Text = "Zpět";
               
                
                
            }
            else
            {
                HistoryPanel.Visible = false;
                UkazaniGrafuZaznam.Visible = false;
                History.Text = "Historie";
            }
            
        }

        
    }

    }



