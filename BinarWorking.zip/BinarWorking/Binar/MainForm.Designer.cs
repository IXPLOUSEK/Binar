﻿namespace Binar
{
    partial class Binar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Binar));
            this.ZacitProcvicovani = new Guna.UI2.WinForms.Guna2Button();
            this.Close = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Back = new Guna.UI2.WinForms.Guna2CircleButton();
            this.MovingPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.Minimalize = new Guna.UI2.WinForms.Guna2CircleButton();
            this.TestButton = new Guna.UI2.WinForms.Guna2Button();
            this.TestPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.Test4 = new Guna.UI2.WinForms.Guna2Button();
            this.Test3 = new Guna.UI2.WinForms.Guna2Button();
            this.Test2 = new Guna.UI2.WinForms.Guna2Button();
            this.Test1 = new Guna.UI2.WinForms.Guna2Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.guna2TextBox5 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2CircleButton1 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton2 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton4 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton3 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton6 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton5 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton8 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton7 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.BinarStart = new Guna.UI2.WinForms.Guna2Button();
            this.soucPanel = new System.Windows.Forms.Panel();
            this.Soucet1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.JmenoCviceni = new System.Windows.Forms.Label();
            this.Info = new System.Windows.Forms.TextBox();
            this.PanelBinSous = new System.Windows.Forms.Panel();
            this.LimitKliknuti = new System.Windows.Forms.Label();
            this.TimerTest = new System.Windows.Forms.Label();
            this.CalculatorPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2CircleButton68 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton67 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton66 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton63 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton65 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton64 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton57 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton58 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton60 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton59 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton61 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton62 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.Remain = new System.Windows.Forms.Label();
            this.Obtiznost = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.BinDecPanelChooser = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.DecBin = new Guna.UI2.WinForms.Guna2ToggleSwitch();
            this.Line7 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.guna2CircleButton49 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton50 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton51 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton52 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton53 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton54 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton55 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton56 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2TextBox7 = new Guna.UI2.WinForms.Guna2TextBox();
            this.Line6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.guna2CircleButton25 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton26 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton27 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton28 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton29 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton30 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton31 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton32 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2TextBox3 = new Guna.UI2.WinForms.Guna2TextBox();
            this.Line3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.guna2CircleButton17 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton18 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton19 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton20 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton21 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton22 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton23 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton24 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            this.Line5 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.guna2CircleButton33 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton34 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton35 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton36 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton37 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton38 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton39 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton40 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2TextBox4 = new Guna.UI2.WinForms.Guna2TextBox();
            this.Line4 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.guna2CircleButton41 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton42 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton43 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton44 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton45 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton46 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton47 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton48 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2TextBox6 = new Guna.UI2.WinForms.Guna2TextBox();
            this.Line2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.guna2CircleButton9 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton10 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton11 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton12 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton13 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton14 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton15 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2CircleButton16 = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.Line1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.TimerLines = new System.Windows.Forms.Timer(this.components);
            this.Title = new System.Windows.Forms.Label();
            this.MovingPanel.SuspendLayout();
            this.TestPanel.SuspendLayout();
            this.soucPanel.SuspendLayout();
            this.PanelBinSous.SuspendLayout();
            this.CalculatorPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Obtiznost)).BeginInit();
            this.BinDecPanelChooser.SuspendLayout();
            this.Line7.SuspendLayout();
            this.panel13.SuspendLayout();
            this.Line6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.Line3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.Line5.SuspendLayout();
            this.panel9.SuspendLayout();
            this.Line4.SuspendLayout();
            this.panel11.SuspendLayout();
            this.Line2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Line1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            this.SuspendLayout();
            // 
            // ZacitProcvicovani
            // 
            this.ZacitProcvicovani.Animated = true;
            this.ZacitProcvicovani.AutoRoundedCorners = true;
            this.ZacitProcvicovani.BackColor = System.Drawing.Color.Transparent;
            this.ZacitProcvicovani.BorderRadius = 34;
            this.ZacitProcvicovani.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ZacitProcvicovani.CustomBorderColor = System.Drawing.Color.White;
            this.ZacitProcvicovani.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.ZacitProcvicovani.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.ZacitProcvicovani.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.ZacitProcvicovani.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.ZacitProcvicovani.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            resources.ApplyResources(this.ZacitProcvicovani, "ZacitProcvicovani");
            this.ZacitProcvicovani.ForeColor = System.Drawing.Color.Black;
            this.ZacitProcvicovani.HoverState.BorderColor = System.Drawing.Color.Black;
            this.ZacitProcvicovani.HoverState.CustomBorderColor = System.Drawing.Color.Black;
            this.ZacitProcvicovani.HoverState.FillColor = System.Drawing.Color.Black;
            this.ZacitProcvicovani.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ZacitProcvicovani.Name = "ZacitProcvicovani";
            this.ZacitProcvicovani.PressedDepth = 0;
            this.ZacitProcvicovani.Click += new System.EventHandler(this.Zacit_Click);
            // 
            // Close
            // 
            this.Close.Animated = true;
            this.Close.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.BorderThickness = 3;
            this.Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Close.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Close.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Close.FillColor = System.Drawing.Color.Maroon;
            resources.ApplyResources(this.Close, "Close");
            this.Close.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.ForeColor = System.Drawing.Color.Maroon;
            this.Close.Name = "Close";
            this.Close.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Close.TabStop = false;
            this.Close.TextOffset = new System.Drawing.Point(1, 1);
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // Back
            // 
            this.Back.Animated = true;
            this.Back.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Back.BorderThickness = 3;
            this.Back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Back.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Back.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Back.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Back.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Back.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.Back, "Back");
            this.Back.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Back.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Back.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Back.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Back.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Back.Name = "Back";
            this.Back.PressedColor = System.Drawing.Color.White;
            this.Back.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Back.TabStop = false;
            this.Back.TextOffset = new System.Drawing.Point(1, 0);
            this.Back.UseTransparentBackground = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // MovingPanel
            // 
            this.MovingPanel.BackColor = System.Drawing.Color.Transparent;
            this.MovingPanel.BorderColor = System.Drawing.Color.Black;
            this.MovingPanel.BorderRadius = 50;
            this.MovingPanel.BorderThickness = 3;
            this.MovingPanel.Controls.Add(this.Back);
            this.MovingPanel.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.MovingPanel.FillColor = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor2 = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor3 = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor4 = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.MovingPanel, "MovingPanel");
            this.MovingPanel.Name = "MovingPanel";
            this.MovingPanel.Quality = 100;
            // 
            // Minimalize
            // 
            this.Minimalize.Animated = true;
            this.Minimalize.BorderColor = System.Drawing.Color.Teal;
            this.Minimalize.BorderThickness = 3;
            this.Minimalize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Minimalize.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Minimalize.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Minimalize.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Minimalize.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Minimalize.FillColor = System.Drawing.Color.MediumTurquoise;
            resources.ApplyResources(this.Minimalize, "Minimalize");
            this.Minimalize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Minimalize.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Minimalize.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Minimalize.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.Minimalize.HoverState.ForeColor = System.Drawing.Color.MediumTurquoise;
            this.Minimalize.Name = "Minimalize";
            this.Minimalize.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Minimalize.TabStop = false;
            this.Minimalize.TextOffset = new System.Drawing.Point(1, -3);
            this.Minimalize.Click += new System.EventHandler(this.Minimalize_Click);
            // 
            // TestButton
            // 
            this.TestButton.Animated = true;
            this.TestButton.AutoRoundedCorners = true;
            this.TestButton.BackColor = System.Drawing.Color.Transparent;
            this.TestButton.BorderRadius = 34;
            this.TestButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TestButton.CustomBorderColor = System.Drawing.Color.White;
            this.TestButton.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.TestButton.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.TestButton.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.TestButton.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.TestButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            resources.ApplyResources(this.TestButton, "TestButton");
            this.TestButton.ForeColor = System.Drawing.Color.Black;
            this.TestButton.HoverState.BorderColor = System.Drawing.Color.Black;
            this.TestButton.HoverState.CustomBorderColor = System.Drawing.Color.Black;
            this.TestButton.HoverState.FillColor = System.Drawing.Color.Black;
            this.TestButton.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.TestButton.Name = "TestButton";
            this.TestButton.PressedDepth = 0;
            this.TestButton.Click += new System.EventHandler(this.TestButton_Click);
            // 
            // TestPanel
            // 
            this.TestPanel.BackColor = System.Drawing.Color.Transparent;
            this.TestPanel.BorderColor = System.Drawing.Color.Black;
            this.TestPanel.BorderRadius = 25;
            this.TestPanel.BorderThickness = 5;
            this.TestPanel.Controls.Add(this.Test4);
            this.TestPanel.Controls.Add(this.Test3);
            this.TestPanel.Controls.Add(this.Test2);
            this.TestPanel.Controls.Add(this.Test1);
            resources.ApplyResources(this.TestPanel, "TestPanel");
            this.TestPanel.Name = "TestPanel";
            // 
            // Test4
            // 
            resources.ApplyResources(this.Test4, "Test4");
            this.Test4.Animated = true;
            this.Test4.AutoRoundedCorners = true;
            this.Test4.BackColor = System.Drawing.Color.Transparent;
            this.Test4.BorderRadius = 34;
            this.Test4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Test4.CustomBorderColor = System.Drawing.Color.White;
            this.Test4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Test4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Test4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Test4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Test4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Test4.ForeColor = System.Drawing.Color.Black;
            this.Test4.HoverState.BorderColor = System.Drawing.Color.Black;
            this.Test4.HoverState.CustomBorderColor = System.Drawing.Color.Black;
            this.Test4.HoverState.FillColor = System.Drawing.Color.Black;
            this.Test4.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Test4.Name = "Test4";
            this.Test4.PressedDepth = 0;
            this.Test4.Click += new System.EventHandler(this.Zacit_Click);
            // 
            // Test3
            // 
            resources.ApplyResources(this.Test3, "Test3");
            this.Test3.Animated = true;
            this.Test3.AutoRoundedCorners = true;
            this.Test3.BackColor = System.Drawing.Color.Transparent;
            this.Test3.BorderRadius = 34;
            this.Test3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Test3.CustomBorderColor = System.Drawing.Color.White;
            this.Test3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Test3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Test3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Test3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Test3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Test3.ForeColor = System.Drawing.Color.Black;
            this.Test3.HoverState.BorderColor = System.Drawing.Color.Black;
            this.Test3.HoverState.CustomBorderColor = System.Drawing.Color.Black;
            this.Test3.HoverState.FillColor = System.Drawing.Color.Black;
            this.Test3.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Test3.Name = "Test3";
            this.Test3.PressedDepth = 0;
            this.Test3.Click += new System.EventHandler(this.Zacit_Click);
            // 
            // Test2
            // 
            resources.ApplyResources(this.Test2, "Test2");
            this.Test2.Animated = true;
            this.Test2.AutoRoundedCorners = true;
            this.Test2.BackColor = System.Drawing.Color.Transparent;
            this.Test2.BorderRadius = 34;
            this.Test2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Test2.CustomBorderColor = System.Drawing.Color.White;
            this.Test2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Test2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Test2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Test2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Test2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Test2.ForeColor = System.Drawing.Color.Black;
            this.Test2.HoverState.BorderColor = System.Drawing.Color.Black;
            this.Test2.HoverState.CustomBorderColor = System.Drawing.Color.Black;
            this.Test2.HoverState.FillColor = System.Drawing.Color.Black;
            this.Test2.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Test2.Name = "Test2";
            this.Test2.PressedDepth = 0;
            this.Test2.Click += new System.EventHandler(this.Zacit_Click);
            // 
            // Test1
            // 
            resources.ApplyResources(this.Test1, "Test1");
            this.Test1.Animated = true;
            this.Test1.AutoRoundedCorners = true;
            this.Test1.BackColor = System.Drawing.Color.Transparent;
            this.Test1.BorderRadius = 34;
            this.Test1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Test1.CustomBorderColor = System.Drawing.Color.White;
            this.Test1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Test1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Test1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Test1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Test1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Test1.ForeColor = System.Drawing.Color.Black;
            this.Test1.HoverState.BorderColor = System.Drawing.Color.Black;
            this.Test1.HoverState.CustomBorderColor = System.Drawing.Color.Black;
            this.Test1.HoverState.FillColor = System.Drawing.Color.Black;
            this.Test1.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Test1.Name = "Test1";
            this.Test1.PressedDepth = 0;
            this.Test1.Click += new System.EventHandler(this.Zacit_Click);
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Name = "label8";
            this.label8.Tag = "";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Name = "label7";
            this.label7.Tag = "";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Name = "label6";
            this.label6.Tag = "";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Name = "label5";
            this.label5.Tag = "";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            this.label4.Tag = "";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            this.label3.Tag = "";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Name = "label2";
            this.label2.Tag = "";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Name = "label1";
            this.label1.Tag = "";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Name = "label21";
            this.label21.Tag = "";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Name = "label20";
            this.label20.Tag = "";
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Name = "label19";
            this.label19.Tag = "";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Name = "label18";
            this.label18.Tag = "";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Name = "label17";
            this.label17.Tag = "";
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Name = "label16";
            this.label16.Tag = "";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Name = "label15";
            this.label15.Tag = "";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Name = "label14";
            this.label14.Tag = "";
            // 
            // guna2TextBox5
            // 
            this.guna2TextBox5.Animated = true;
            this.guna2TextBox5.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox5.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox5.BorderRadius = 15;
            this.guna2TextBox5.BorderThickness = 0;
            this.guna2TextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox5.DefaultText = "0";
            this.guna2TextBox5.DisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2TextBox5.DisabledState.ForeColor = System.Drawing.Color.SlateBlue;
            this.guna2TextBox5.DisabledState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2TextBox5.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            resources.ApplyResources(this.guna2TextBox5, "guna2TextBox5");
            this.guna2TextBox5.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2TextBox5.HoverState.BorderColor = System.Drawing.Color.White;
            this.guna2TextBox5.MaxLength = 3;
            this.guna2TextBox5.Name = "guna2TextBox5";
            this.guna2TextBox5.PasswordChar = '\0';
            this.guna2TextBox5.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2TextBox5.PlaceholderText = "";
            this.guna2TextBox5.SelectedText = "";
            this.guna2TextBox5.TabStop = false;
            this.guna2TextBox5.Tag = "9";
            this.guna2TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2TextBox5.TextChanged += new System.EventHandler(this.FinalNumber_TextChanged);
            this.guna2TextBox5.Enter += new System.EventHandler(this.binartextbox_enter);
            this.guna2TextBox5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FinalNumber_MouseClick);
            // 
            // guna2CircleButton1
            // 
            resources.ApplyResources(this.guna2CircleButton1, "guna2CircleButton1");
            this.guna2CircleButton1.Animated = true;
            this.guna2CircleButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton1.Name = "guna2CircleButton1";
            this.guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton1.TabStop = false;
            this.guna2CircleButton1.Tag = "8";
            this.guna2CircleButton1.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton1.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton2
            // 
            resources.ApplyResources(this.guna2CircleButton2, "guna2CircleButton2");
            this.guna2CircleButton2.Animated = true;
            this.guna2CircleButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton2.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton2.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton2.Name = "guna2CircleButton2";
            this.guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton2.TabStop = false;
            this.guna2CircleButton2.Tag = "7";
            this.guna2CircleButton2.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton2.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton4
            // 
            resources.ApplyResources(this.guna2CircleButton4, "guna2CircleButton4");
            this.guna2CircleButton4.Animated = true;
            this.guna2CircleButton4.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton4.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton4.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton4.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton4.Name = "guna2CircleButton4";
            this.guna2CircleButton4.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton4.TabStop = false;
            this.guna2CircleButton4.Tag = "6";
            this.guna2CircleButton4.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton4.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton3
            // 
            resources.ApplyResources(this.guna2CircleButton3, "guna2CircleButton3");
            this.guna2CircleButton3.Animated = true;
            this.guna2CircleButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton3.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton3.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton3.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton3.Name = "guna2CircleButton3";
            this.guna2CircleButton3.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton3.TabStop = false;
            this.guna2CircleButton3.Tag = "5";
            this.guna2CircleButton3.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton3.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton6
            // 
            resources.ApplyResources(this.guna2CircleButton6, "guna2CircleButton6");
            this.guna2CircleButton6.Animated = true;
            this.guna2CircleButton6.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton6.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton6.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton6.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton6.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton6.Name = "guna2CircleButton6";
            this.guna2CircleButton6.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton6.TabStop = false;
            this.guna2CircleButton6.Tag = "4";
            this.guna2CircleButton6.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton6.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton5
            // 
            resources.ApplyResources(this.guna2CircleButton5, "guna2CircleButton5");
            this.guna2CircleButton5.Animated = true;
            this.guna2CircleButton5.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton5.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton5.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton5.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton5.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton5.Name = "guna2CircleButton5";
            this.guna2CircleButton5.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton5.TabStop = false;
            this.guna2CircleButton5.Tag = "3";
            this.guna2CircleButton5.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton5.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton8
            // 
            resources.ApplyResources(this.guna2CircleButton8, "guna2CircleButton8");
            this.guna2CircleButton8.Animated = true;
            this.guna2CircleButton8.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton8.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton8.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton8.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton8.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton8.Name = "guna2CircleButton8";
            this.guna2CircleButton8.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton8.TabStop = false;
            this.guna2CircleButton8.Tag = "2";
            this.guna2CircleButton8.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton8.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton7
            // 
            resources.ApplyResources(this.guna2CircleButton7, "guna2CircleButton7");
            this.guna2CircleButton7.Animated = true;
            this.guna2CircleButton7.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton7.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton7.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton7.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton7.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton7.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton7.Name = "guna2CircleButton7";
            this.guna2CircleButton7.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton7.TabStop = false;
            this.guna2CircleButton7.Tag = "1";
            this.guna2CircleButton7.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton7.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // BinarStart
            // 
            this.BinarStart.Animated = true;
            this.BinarStart.AutoRoundedCorners = true;
            this.BinarStart.BackColor = System.Drawing.Color.Transparent;
            this.BinarStart.BorderRadius = 22;
            this.BinarStart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BinarStart.CustomBorderColor = System.Drawing.Color.White;
            this.BinarStart.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BinarStart.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BinarStart.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BinarStart.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BinarStart.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            resources.ApplyResources(this.BinarStart, "BinarStart");
            this.BinarStart.ForeColor = System.Drawing.Color.Olive;
            this.BinarStart.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.BinarStart.HoverState.CustomBorderColor = System.Drawing.Color.Transparent;
            this.BinarStart.HoverState.FillColor = System.Drawing.Color.Olive;
            this.BinarStart.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.BinarStart.Name = "BinarStart";
            this.BinarStart.PressedDepth = 0;
            this.BinarStart.TabStop = false;
            this.BinarStart.TextOffset = new System.Drawing.Point(2, 0);
            this.BinarStart.Click += new System.EventHandler(this.BinarStart_Click);
            // 
            // soucPanel
            // 
            this.soucPanel.Controls.Add(this.Soucet1);
            this.soucPanel.Controls.Add(this.label24);
            resources.ApplyResources(this.soucPanel, "soucPanel");
            this.soucPanel.Name = "soucPanel";
            this.soucPanel.Tag = "10";
            // 
            // Soucet1
            // 
            resources.ApplyResources(this.Soucet1, "Soucet1");
            this.Soucet1.ForeColor = System.Drawing.Color.White;
            this.Soucet1.Name = "Soucet1";
            this.Soucet1.Tag = "1";
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Name = "label24";
            // 
            // JmenoCviceni
            // 
            resources.ApplyResources(this.JmenoCviceni, "JmenoCviceni");
            this.JmenoCviceni.ForeColor = System.Drawing.Color.White;
            this.JmenoCviceni.Name = "JmenoCviceni";
            // 
            // Info
            // 
            this.Info.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Info.Cursor = System.Windows.Forms.Cursors.Help;
            resources.ApplyResources(this.Info, "Info");
            this.Info.ForeColor = System.Drawing.SystemColors.Info;
            this.Info.Name = "Info";
            this.Info.ReadOnly = true;
            this.Info.ShortcutsEnabled = false;
            this.Info.MouseEnter += new System.EventHandler(this.Info_MouseEnter);
            this.Info.MouseLeave += new System.EventHandler(this.Info_MouseLeave);
            // 
            // PanelBinSous
            // 
            resources.ApplyResources(this.PanelBinSous, "PanelBinSous");
            this.PanelBinSous.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.PanelBinSous.Controls.Add(this.Info);
            this.PanelBinSous.Controls.Add(this.LimitKliknuti);
            this.PanelBinSous.Controls.Add(this.TimerTest);
            this.PanelBinSous.Controls.Add(this.CalculatorPanel);
            this.PanelBinSous.Controls.Add(this.Remain);
            this.PanelBinSous.Controls.Add(this.Obtiznost);
            this.PanelBinSous.Controls.Add(this.label38);
            this.PanelBinSous.Controls.Add(this.BinDecPanelChooser);
            this.PanelBinSous.Controls.Add(this.Line7);
            this.PanelBinSous.Controls.Add(this.Line6);
            this.PanelBinSous.Controls.Add(this.Line3);
            this.PanelBinSous.Controls.Add(this.Line5);
            this.PanelBinSous.Controls.Add(this.Line4);
            this.PanelBinSous.Controls.Add(this.Line2);
            this.PanelBinSous.Controls.Add(this.Line1);
            this.PanelBinSous.Controls.Add(this.JmenoCviceni);
            this.PanelBinSous.Controls.Add(this.BinarStart);
            this.PanelBinSous.Controls.Add(this.label14);
            this.PanelBinSous.Controls.Add(this.label15);
            this.PanelBinSous.Controls.Add(this.label16);
            this.PanelBinSous.Controls.Add(this.label17);
            this.PanelBinSous.Controls.Add(this.label18);
            this.PanelBinSous.Controls.Add(this.label19);
            this.PanelBinSous.Controls.Add(this.label20);
            this.PanelBinSous.Controls.Add(this.label21);
            this.PanelBinSous.Controls.Add(this.label1);
            this.PanelBinSous.Controls.Add(this.label2);
            this.PanelBinSous.Controls.Add(this.label3);
            this.PanelBinSous.Controls.Add(this.label4);
            this.PanelBinSous.Controls.Add(this.label5);
            this.PanelBinSous.Controls.Add(this.label6);
            this.PanelBinSous.Controls.Add(this.label7);
            this.PanelBinSous.Controls.Add(this.label8);
            this.PanelBinSous.Controls.Add(this.label13);
            this.PanelBinSous.Name = "PanelBinSous";
            this.PanelBinSous.TabStop = true;
            this.PanelBinSous.Tag = "";
            this.PanelBinSous.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelBinSous_Paint);
            // 
            // LimitKliknuti
            // 
            resources.ApplyResources(this.LimitKliknuti, "LimitKliknuti");
            this.LimitKliknuti.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.LimitKliknuti.Name = "LimitKliknuti";
            // 
            // TimerTest
            // 
            resources.ApplyResources(this.TimerTest, "TimerTest");
            this.TimerTest.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.TimerTest.Name = "TimerTest";
            // 
            // CalculatorPanel
            // 
            this.CalculatorPanel.BorderColor = System.Drawing.Color.Black;
            this.CalculatorPanel.BorderRadius = 25;
            this.CalculatorPanel.BorderThickness = 5;
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton68);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton67);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton66);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton63);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton65);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton64);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton57);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton58);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton60);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton59);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton61);
            this.CalculatorPanel.Controls.Add(this.guna2CircleButton62);
            this.CalculatorPanel.CustomBorderColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.CalculatorPanel, "CalculatorPanel");
            this.CalculatorPanel.Name = "CalculatorPanel";
            // 
            // guna2CircleButton68
            // 
            this.guna2CircleButton68.Animated = true;
            this.guna2CircleButton68.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton68.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton68.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton68.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton68.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton68.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton68, "guna2CircleButton68");
            this.guna2CircleButton68.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton68.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton68.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton68.Name = "guna2CircleButton68";
            this.guna2CircleButton68.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton68.TabStop = false;
            this.guna2CircleButton68.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton68.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton67
            // 
            this.guna2CircleButton67.Animated = true;
            this.guna2CircleButton67.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton67.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton67.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton67.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton67.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton67.FillColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.guna2CircleButton67, "guna2CircleButton67");
            this.guna2CircleButton67.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton67.HoverState.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton67.HoverState.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton67.Name = "guna2CircleButton67";
            this.guna2CircleButton67.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton67.TabStop = false;
            this.guna2CircleButton67.TextOffset = new System.Drawing.Point(2, -1);
            this.guna2CircleButton67.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton66
            // 
            this.guna2CircleButton66.Animated = true;
            this.guna2CircleButton66.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton66.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton66.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton66.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton66.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton66.FillColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.guna2CircleButton66, "guna2CircleButton66");
            this.guna2CircleButton66.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton66.HoverState.FillColor = System.Drawing.Color.White;
            this.guna2CircleButton66.HoverState.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton66.Name = "guna2CircleButton66";
            this.guna2CircleButton66.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton66.TabStop = false;
            this.guna2CircleButton66.Tag = "";
            this.guna2CircleButton66.TextOffset = new System.Drawing.Point(0, -1);
            this.guna2CircleButton66.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton63
            // 
            this.guna2CircleButton63.Animated = true;
            this.guna2CircleButton63.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton63.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton63.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton63.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton63.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton63.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton63, "guna2CircleButton63");
            this.guna2CircleButton63.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton63.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton63.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton63.Name = "guna2CircleButton63";
            this.guna2CircleButton63.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton63.TabStop = false;
            this.guna2CircleButton63.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton63.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton65
            // 
            this.guna2CircleButton65.Animated = true;
            this.guna2CircleButton65.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton65.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton65.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton65.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton65.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton65.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton65, "guna2CircleButton65");
            this.guna2CircleButton65.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton65.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton65.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton65.Name = "guna2CircleButton65";
            this.guna2CircleButton65.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton65.TabStop = false;
            this.guna2CircleButton65.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton65.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton64
            // 
            this.guna2CircleButton64.Animated = true;
            this.guna2CircleButton64.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton64.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton64.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton64.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton64.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton64.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton64, "guna2CircleButton64");
            this.guna2CircleButton64.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton64.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton64.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton64.Name = "guna2CircleButton64";
            this.guna2CircleButton64.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton64.TabStop = false;
            this.guna2CircleButton64.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton64.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton57
            // 
            this.guna2CircleButton57.Animated = true;
            this.guna2CircleButton57.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton57.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton57.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton57.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton57.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton57.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton57, "guna2CircleButton57");
            this.guna2CircleButton57.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton57.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton57.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton57.Name = "guna2CircleButton57";
            this.guna2CircleButton57.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton57.TabStop = false;
            this.guna2CircleButton57.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton57.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton58
            // 
            this.guna2CircleButton58.Animated = true;
            this.guna2CircleButton58.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton58.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton58.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton58.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton58.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton58.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton58, "guna2CircleButton58");
            this.guna2CircleButton58.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton58.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton58.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton58.Name = "guna2CircleButton58";
            this.guna2CircleButton58.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton58.TabStop = false;
            this.guna2CircleButton58.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton58.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton60
            // 
            this.guna2CircleButton60.Animated = true;
            this.guna2CircleButton60.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton60.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton60.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton60.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton60.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton60.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton60, "guna2CircleButton60");
            this.guna2CircleButton60.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton60.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton60.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton60.Name = "guna2CircleButton60";
            this.guna2CircleButton60.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton60.TabStop = false;
            this.guna2CircleButton60.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton60.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton59
            // 
            this.guna2CircleButton59.Animated = true;
            this.guna2CircleButton59.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton59.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton59.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton59.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton59.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton59.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton59, "guna2CircleButton59");
            this.guna2CircleButton59.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton59.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton59.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton59.Name = "guna2CircleButton59";
            this.guna2CircleButton59.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton59.TabStop = false;
            this.guna2CircleButton59.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton59.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton61
            // 
            this.guna2CircleButton61.Animated = true;
            this.guna2CircleButton61.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton61.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton61.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton61.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton61.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton61.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton61, "guna2CircleButton61");
            this.guna2CircleButton61.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton61.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton61.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton61.Name = "guna2CircleButton61";
            this.guna2CircleButton61.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton61.TabStop = false;
            this.guna2CircleButton61.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton61.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // guna2CircleButton62
            // 
            this.guna2CircleButton62.Animated = true;
            this.guna2CircleButton62.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton62.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton62.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2CircleButton62.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2CircleButton62.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2CircleButton62.FillColor = System.Drawing.Color.White;
            resources.ApplyResources(this.guna2CircleButton62, "guna2CircleButton62");
            this.guna2CircleButton62.ForeColor = System.Drawing.Color.Black;
            this.guna2CircleButton62.HoverState.FillColor = System.Drawing.Color.Black;
            this.guna2CircleButton62.HoverState.ForeColor = System.Drawing.Color.White;
            this.guna2CircleButton62.Name = "guna2CircleButton62";
            this.guna2CircleButton62.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton62.TabStop = false;
            this.guna2CircleButton62.TextOffset = new System.Drawing.Point(2, -3);
            this.guna2CircleButton62.Click += new System.EventHandler(this.CalculatorButton_Click);
            // 
            // Remain
            // 
            resources.ApplyResources(this.Remain, "Remain");
            this.Remain.ForeColor = System.Drawing.Color.White;
            this.Remain.Name = "Remain";
            // 
            // Obtiznost
            // 
            resources.ApplyResources(this.Obtiznost, "Obtiznost");
            this.Obtiznost.BackColor = System.Drawing.Color.Transparent;
            this.Obtiznost.BorderRadius = 11;
            this.Obtiznost.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Obtiznost.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.Obtiznost.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Obtiznost.Name = "Obtiznost";
            this.Obtiznost.TabStop = false;
            this.Obtiznost.UpDownButtonFillColor = System.Drawing.Color.White;
            this.Obtiznost.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label38
            // 
            resources.ApplyResources(this.label38, "label38");
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Name = "label38";
            // 
            // BinDecPanelChooser
            // 
            this.BinDecPanelChooser.Controls.Add(this.label35);
            this.BinDecPanelChooser.Controls.Add(this.label22);
            this.BinDecPanelChooser.Controls.Add(this.DecBin);
            resources.ApplyResources(this.BinDecPanelChooser, "BinDecPanelChooser");
            this.BinDecPanelChooser.Name = "BinDecPanelChooser";
            // 
            // label35
            // 
            resources.ApplyResources(this.label35, "label35");
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Name = "label35";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Name = "label22";
            // 
            // DecBin
            // 
            this.DecBin.Animated = true;
            this.DecBin.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.DecBin.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.DecBin.CheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.DecBin.CheckedState.InnerColor = System.Drawing.Color.White;
            this.DecBin.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.DecBin, "DecBin");
            this.DecBin.Name = "DecBin";
            this.DecBin.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.DecBin.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.DecBin.UncheckedState.InnerBorderColor = System.Drawing.Color.White;
            this.DecBin.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.DecBin.CheckedChanged += new System.EventHandler(this.DecBin_CheckedChanged);
            // 
            // Line7
            // 
            this.Line7.BackColor = System.Drawing.Color.Transparent;
            this.Line7.Controls.Add(this.panel13);
            this.Line7.Controls.Add(this.guna2CircleButton49);
            this.Line7.Controls.Add(this.guna2CircleButton50);
            this.Line7.Controls.Add(this.guna2CircleButton51);
            this.Line7.Controls.Add(this.guna2CircleButton52);
            this.Line7.Controls.Add(this.guna2CircleButton53);
            this.Line7.Controls.Add(this.guna2CircleButton54);
            this.Line7.Controls.Add(this.guna2CircleButton55);
            this.Line7.Controls.Add(this.guna2CircleButton56);
            this.Line7.Controls.Add(this.guna2TextBox7);
            resources.ApplyResources(this.Line7, "Line7");
            this.Line7.Name = "Line7";
            this.Line7.Tag = "7";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.label36);
            this.panel13.Controls.Add(this.label37);
            resources.ApplyResources(this.panel13, "panel13");
            this.panel13.Name = "panel13";
            this.panel13.Tag = "10";
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Name = "label36";
            this.label36.Tag = "1";
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Name = "label37";
            // 
            // guna2CircleButton49
            // 
            resources.ApplyResources(this.guna2CircleButton49, "guna2CircleButton49");
            this.guna2CircleButton49.Animated = true;
            this.guna2CircleButton49.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton49.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton49.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton49.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton49.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton49.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton49.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton49.Name = "guna2CircleButton49";
            this.guna2CircleButton49.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton49.TabStop = false;
            this.guna2CircleButton49.Tag = "1";
            this.guna2CircleButton49.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton49.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton50
            // 
            resources.ApplyResources(this.guna2CircleButton50, "guna2CircleButton50");
            this.guna2CircleButton50.Animated = true;
            this.guna2CircleButton50.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton50.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton50.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton50.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton50.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton50.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton50.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton50.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton50.Name = "guna2CircleButton50";
            this.guna2CircleButton50.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton50.TabStop = false;
            this.guna2CircleButton50.Tag = "2";
            this.guna2CircleButton50.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton50.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton51
            // 
            resources.ApplyResources(this.guna2CircleButton51, "guna2CircleButton51");
            this.guna2CircleButton51.Animated = true;
            this.guna2CircleButton51.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton51.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton51.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton51.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton51.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton51.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton51.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton51.Name = "guna2CircleButton51";
            this.guna2CircleButton51.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton51.TabStop = false;
            this.guna2CircleButton51.Tag = "3";
            this.guna2CircleButton51.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton51.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton52
            // 
            resources.ApplyResources(this.guna2CircleButton52, "guna2CircleButton52");
            this.guna2CircleButton52.Animated = true;
            this.guna2CircleButton52.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton52.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton52.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton52.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton52.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton52.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton52.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton52.Name = "guna2CircleButton52";
            this.guna2CircleButton52.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton52.TabStop = false;
            this.guna2CircleButton52.Tag = "4";
            this.guna2CircleButton52.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton52.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton53
            // 
            resources.ApplyResources(this.guna2CircleButton53, "guna2CircleButton53");
            this.guna2CircleButton53.Animated = true;
            this.guna2CircleButton53.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton53.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton53.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton53.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton53.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton53.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton53.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton53.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton53.Name = "guna2CircleButton53";
            this.guna2CircleButton53.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton53.TabStop = false;
            this.guna2CircleButton53.Tag = "5";
            this.guna2CircleButton53.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton53.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton54
            // 
            resources.ApplyResources(this.guna2CircleButton54, "guna2CircleButton54");
            this.guna2CircleButton54.Animated = true;
            this.guna2CircleButton54.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton54.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton54.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton54.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton54.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton54.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton54.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton54.Name = "guna2CircleButton54";
            this.guna2CircleButton54.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton54.TabStop = false;
            this.guna2CircleButton54.Tag = "6";
            this.guna2CircleButton54.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton54.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton55
            // 
            resources.ApplyResources(this.guna2CircleButton55, "guna2CircleButton55");
            this.guna2CircleButton55.Animated = true;
            this.guna2CircleButton55.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton55.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton55.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton55.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton55.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton55.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton55.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton55.Name = "guna2CircleButton55";
            this.guna2CircleButton55.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton55.TabStop = false;
            this.guna2CircleButton55.Tag = "7";
            this.guna2CircleButton55.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton55.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton56
            // 
            resources.ApplyResources(this.guna2CircleButton56, "guna2CircleButton56");
            this.guna2CircleButton56.Animated = true;
            this.guna2CircleButton56.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton56.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton56.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton56.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton56.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton56.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton56.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton56.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton56.Name = "guna2CircleButton56";
            this.guna2CircleButton56.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton56.TabStop = false;
            this.guna2CircleButton56.Tag = "8";
            this.guna2CircleButton56.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton56.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2TextBox7
            // 
            this.guna2TextBox7.Animated = true;
            this.guna2TextBox7.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox7.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox7.BorderRadius = 15;
            this.guna2TextBox7.BorderThickness = 0;
            this.guna2TextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox7.DefaultText = "0";
            this.guna2TextBox7.DisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox7.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2TextBox7.DisabledState.ForeColor = System.Drawing.Color.SlateBlue;
            this.guna2TextBox7.DisabledState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2TextBox7.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            resources.ApplyResources(this.guna2TextBox7, "guna2TextBox7");
            this.guna2TextBox7.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2TextBox7.HoverState.BorderColor = System.Drawing.Color.White;
            this.guna2TextBox7.MaxLength = 3;
            this.guna2TextBox7.Name = "guna2TextBox7";
            this.guna2TextBox7.PasswordChar = '\0';
            this.guna2TextBox7.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2TextBox7.PlaceholderText = "";
            this.guna2TextBox7.SelectedText = "";
            this.guna2TextBox7.TabStop = false;
            this.guna2TextBox7.Tag = "9";
            this.guna2TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2TextBox7.TextChanged += new System.EventHandler(this.FinalNumber_TextChanged);
            this.guna2TextBox7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FinalNumber_MouseClick);
            // 
            // Line6
            // 
            this.Line6.BackColor = System.Drawing.Color.Transparent;
            this.Line6.Controls.Add(this.panel7);
            this.Line6.Controls.Add(this.guna2CircleButton25);
            this.Line6.Controls.Add(this.guna2CircleButton26);
            this.Line6.Controls.Add(this.guna2CircleButton27);
            this.Line6.Controls.Add(this.guna2CircleButton28);
            this.Line6.Controls.Add(this.guna2CircleButton29);
            this.Line6.Controls.Add(this.guna2CircleButton30);
            this.Line6.Controls.Add(this.guna2CircleButton31);
            this.Line6.Controls.Add(this.guna2CircleButton32);
            this.Line6.Controls.Add(this.guna2TextBox3);
            resources.ApplyResources(this.Line6, "Line6");
            this.Line6.Name = "Line6";
            this.Line6.Tag = "6";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label29);
            this.panel7.Controls.Add(this.label30);
            resources.ApplyResources(this.panel7, "panel7");
            this.panel7.Name = "panel7";
            this.panel7.Tag = "10";
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Name = "label29";
            this.label29.Tag = "1";
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Name = "label30";
            // 
            // guna2CircleButton25
            // 
            resources.ApplyResources(this.guna2CircleButton25, "guna2CircleButton25");
            this.guna2CircleButton25.Animated = true;
            this.guna2CircleButton25.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton25.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton25.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton25.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton25.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton25.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton25.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton25.Name = "guna2CircleButton25";
            this.guna2CircleButton25.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton25.TabStop = false;
            this.guna2CircleButton25.Tag = "1";
            this.guna2CircleButton25.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton25.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton26
            // 
            resources.ApplyResources(this.guna2CircleButton26, "guna2CircleButton26");
            this.guna2CircleButton26.Animated = true;
            this.guna2CircleButton26.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton26.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton26.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton26.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton26.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton26.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton26.Name = "guna2CircleButton26";
            this.guna2CircleButton26.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton26.TabStop = false;
            this.guna2CircleButton26.Tag = "2";
            this.guna2CircleButton26.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton26.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton27
            // 
            resources.ApplyResources(this.guna2CircleButton27, "guna2CircleButton27");
            this.guna2CircleButton27.Animated = true;
            this.guna2CircleButton27.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton27.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton27.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton27.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton27.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton27.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton27.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton27.Name = "guna2CircleButton27";
            this.guna2CircleButton27.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton27.TabStop = false;
            this.guna2CircleButton27.Tag = "3";
            this.guna2CircleButton27.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton27.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton28
            // 
            resources.ApplyResources(this.guna2CircleButton28, "guna2CircleButton28");
            this.guna2CircleButton28.Animated = true;
            this.guna2CircleButton28.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton28.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton28.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton28.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton28.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton28.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton28.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton28.Name = "guna2CircleButton28";
            this.guna2CircleButton28.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton28.TabStop = false;
            this.guna2CircleButton28.Tag = "4";
            this.guna2CircleButton28.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton28.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton29
            // 
            resources.ApplyResources(this.guna2CircleButton29, "guna2CircleButton29");
            this.guna2CircleButton29.Animated = true;
            this.guna2CircleButton29.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton29.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton29.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton29.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton29.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton29.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton29.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton29.Name = "guna2CircleButton29";
            this.guna2CircleButton29.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton29.TabStop = false;
            this.guna2CircleButton29.Tag = "5";
            this.guna2CircleButton29.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton29.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton30
            // 
            resources.ApplyResources(this.guna2CircleButton30, "guna2CircleButton30");
            this.guna2CircleButton30.Animated = true;
            this.guna2CircleButton30.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton30.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton30.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton30.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton30.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton30.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton30.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton30.Name = "guna2CircleButton30";
            this.guna2CircleButton30.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton30.TabStop = false;
            this.guna2CircleButton30.Tag = "6";
            this.guna2CircleButton30.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton30.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton31
            // 
            resources.ApplyResources(this.guna2CircleButton31, "guna2CircleButton31");
            this.guna2CircleButton31.Animated = true;
            this.guna2CircleButton31.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton31.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton31.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton31.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton31.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton31.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton31.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton31.Name = "guna2CircleButton31";
            this.guna2CircleButton31.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton31.TabStop = false;
            this.guna2CircleButton31.Tag = "7";
            this.guna2CircleButton31.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton31.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton32
            // 
            resources.ApplyResources(this.guna2CircleButton32, "guna2CircleButton32");
            this.guna2CircleButton32.Animated = true;
            this.guna2CircleButton32.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton32.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton32.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton32.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton32.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton32.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton32.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton32.Name = "guna2CircleButton32";
            this.guna2CircleButton32.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton32.TabStop = false;
            this.guna2CircleButton32.Tag = "8";
            this.guna2CircleButton32.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton32.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2TextBox3
            // 
            this.guna2TextBox3.Animated = true;
            this.guna2TextBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox3.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox3.BorderRadius = 15;
            this.guna2TextBox3.BorderThickness = 0;
            this.guna2TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox3.DefaultText = "0";
            this.guna2TextBox3.DisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2TextBox3.DisabledState.ForeColor = System.Drawing.Color.SlateBlue;
            this.guna2TextBox3.DisabledState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2TextBox3.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            resources.ApplyResources(this.guna2TextBox3, "guna2TextBox3");
            this.guna2TextBox3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2TextBox3.HoverState.BorderColor = System.Drawing.Color.White;
            this.guna2TextBox3.MaxLength = 3;
            this.guna2TextBox3.Name = "guna2TextBox3";
            this.guna2TextBox3.PasswordChar = '\0';
            this.guna2TextBox3.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2TextBox3.PlaceholderText = "";
            this.guna2TextBox3.SelectedText = "";
            this.guna2TextBox3.TabStop = false;
            this.guna2TextBox3.Tag = "9";
            this.guna2TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2TextBox3.TextChanged += new System.EventHandler(this.FinalNumber_TextChanged);
            this.guna2TextBox3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FinalNumber_MouseClick);
            // 
            // Line3
            // 
            this.Line3.BackColor = System.Drawing.Color.Transparent;
            this.Line3.Controls.Add(this.panel5);
            this.Line3.Controls.Add(this.guna2CircleButton17);
            this.Line3.Controls.Add(this.guna2CircleButton18);
            this.Line3.Controls.Add(this.guna2CircleButton19);
            this.Line3.Controls.Add(this.guna2CircleButton20);
            this.Line3.Controls.Add(this.guna2CircleButton21);
            this.Line3.Controls.Add(this.guna2CircleButton22);
            this.Line3.Controls.Add(this.guna2CircleButton23);
            this.Line3.Controls.Add(this.guna2CircleButton24);
            this.Line3.Controls.Add(this.guna2TextBox2);
            resources.ApplyResources(this.Line3, "Line3");
            this.Line3.Name = "Line3";
            this.Line3.Tag = "3";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label27);
            this.panel5.Controls.Add(this.label28);
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            this.panel5.Tag = "10";
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Name = "label27";
            this.label27.Tag = "1";
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Name = "label28";
            // 
            // guna2CircleButton17
            // 
            resources.ApplyResources(this.guna2CircleButton17, "guna2CircleButton17");
            this.guna2CircleButton17.Animated = true;
            this.guna2CircleButton17.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton17.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton17.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton17.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton17.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton17.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton17.Name = "guna2CircleButton17";
            this.guna2CircleButton17.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton17.TabStop = false;
            this.guna2CircleButton17.Tag = "1";
            this.guna2CircleButton17.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton17.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton18
            // 
            resources.ApplyResources(this.guna2CircleButton18, "guna2CircleButton18");
            this.guna2CircleButton18.Animated = true;
            this.guna2CircleButton18.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton18.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton18.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton18.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton18.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton18.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton18.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton18.Name = "guna2CircleButton18";
            this.guna2CircleButton18.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton18.TabStop = false;
            this.guna2CircleButton18.Tag = "2";
            this.guna2CircleButton18.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton18.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton19
            // 
            resources.ApplyResources(this.guna2CircleButton19, "guna2CircleButton19");
            this.guna2CircleButton19.Animated = true;
            this.guna2CircleButton19.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton19.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton19.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton19.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton19.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton19.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton19.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton19.Name = "guna2CircleButton19";
            this.guna2CircleButton19.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton19.TabStop = false;
            this.guna2CircleButton19.Tag = "3";
            this.guna2CircleButton19.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton19.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton20
            // 
            resources.ApplyResources(this.guna2CircleButton20, "guna2CircleButton20");
            this.guna2CircleButton20.Animated = true;
            this.guna2CircleButton20.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton20.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton20.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton20.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton20.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton20.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton20.Name = "guna2CircleButton20";
            this.guna2CircleButton20.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton20.TabStop = false;
            this.guna2CircleButton20.Tag = "4";
            this.guna2CircleButton20.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton20.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton21
            // 
            resources.ApplyResources(this.guna2CircleButton21, "guna2CircleButton21");
            this.guna2CircleButton21.Animated = true;
            this.guna2CircleButton21.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton21.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton21.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton21.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton21.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton21.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton21.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton21.Name = "guna2CircleButton21";
            this.guna2CircleButton21.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton21.TabStop = false;
            this.guna2CircleButton21.Tag = "5";
            this.guna2CircleButton21.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton21.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton22
            // 
            resources.ApplyResources(this.guna2CircleButton22, "guna2CircleButton22");
            this.guna2CircleButton22.Animated = true;
            this.guna2CircleButton22.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton22.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton22.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton22.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton22.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton22.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton22.Name = "guna2CircleButton22";
            this.guna2CircleButton22.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton22.TabStop = false;
            this.guna2CircleButton22.Tag = "6";
            this.guna2CircleButton22.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton22.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton23
            // 
            resources.ApplyResources(this.guna2CircleButton23, "guna2CircleButton23");
            this.guna2CircleButton23.Animated = true;
            this.guna2CircleButton23.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton23.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton23.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton23.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton23.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton23.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton23.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton23.Name = "guna2CircleButton23";
            this.guna2CircleButton23.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton23.TabStop = false;
            this.guna2CircleButton23.Tag = "7";
            this.guna2CircleButton23.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton23.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton24
            // 
            resources.ApplyResources(this.guna2CircleButton24, "guna2CircleButton24");
            this.guna2CircleButton24.Animated = true;
            this.guna2CircleButton24.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton24.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton24.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton24.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton24.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton24.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton24.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton24.Name = "guna2CircleButton24";
            this.guna2CircleButton24.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton24.TabStop = false;
            this.guna2CircleButton24.Tag = "8";
            this.guna2CircleButton24.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton24.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2TextBox2
            // 
            this.guna2TextBox2.Animated = true;
            this.guna2TextBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox2.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox2.BorderRadius = 15;
            this.guna2TextBox2.BorderThickness = 0;
            this.guna2TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox2.DefaultText = "0";
            this.guna2TextBox2.DisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2TextBox2.DisabledState.ForeColor = System.Drawing.Color.SlateBlue;
            this.guna2TextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2TextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            resources.ApplyResources(this.guna2TextBox2, "guna2TextBox2");
            this.guna2TextBox2.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2TextBox2.HoverState.BorderColor = System.Drawing.Color.White;
            this.guna2TextBox2.MaxLength = 3;
            this.guna2TextBox2.Name = "guna2TextBox2";
            this.guna2TextBox2.PasswordChar = '\0';
            this.guna2TextBox2.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2TextBox2.PlaceholderText = "";
            this.guna2TextBox2.SelectedText = "";
            this.guna2TextBox2.TabStop = false;
            this.guna2TextBox2.Tag = "9";
            this.guna2TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2TextBox2.TextChanged += new System.EventHandler(this.FinalNumber_TextChanged);
            this.guna2TextBox2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FinalNumber_MouseClick);
            // 
            // Line5
            // 
            this.Line5.BackColor = System.Drawing.Color.Transparent;
            this.Line5.Controls.Add(this.panel9);
            this.Line5.Controls.Add(this.guna2CircleButton33);
            this.Line5.Controls.Add(this.guna2CircleButton34);
            this.Line5.Controls.Add(this.guna2CircleButton35);
            this.Line5.Controls.Add(this.guna2CircleButton36);
            this.Line5.Controls.Add(this.guna2CircleButton37);
            this.Line5.Controls.Add(this.guna2CircleButton38);
            this.Line5.Controls.Add(this.guna2CircleButton39);
            this.Line5.Controls.Add(this.guna2CircleButton40);
            this.Line5.Controls.Add(this.guna2TextBox4);
            resources.ApplyResources(this.Line5, "Line5");
            this.Line5.Name = "Line5";
            this.Line5.Tag = "5";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label31);
            this.panel9.Controls.Add(this.label32);
            resources.ApplyResources(this.panel9, "panel9");
            this.panel9.Name = "panel9";
            this.panel9.Tag = "10";
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Name = "label31";
            this.label31.Tag = "1";
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Name = "label32";
            // 
            // guna2CircleButton33
            // 
            resources.ApplyResources(this.guna2CircleButton33, "guna2CircleButton33");
            this.guna2CircleButton33.Animated = true;
            this.guna2CircleButton33.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton33.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton33.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton33.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton33.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton33.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton33.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton33.Name = "guna2CircleButton33";
            this.guna2CircleButton33.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton33.TabStop = false;
            this.guna2CircleButton33.Tag = "1";
            this.guna2CircleButton33.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton33.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton34
            // 
            resources.ApplyResources(this.guna2CircleButton34, "guna2CircleButton34");
            this.guna2CircleButton34.Animated = true;
            this.guna2CircleButton34.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton34.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton34.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton34.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton34.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton34.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton34.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton34.Name = "guna2CircleButton34";
            this.guna2CircleButton34.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton34.TabStop = false;
            this.guna2CircleButton34.Tag = "2";
            this.guna2CircleButton34.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton34.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton35
            // 
            resources.ApplyResources(this.guna2CircleButton35, "guna2CircleButton35");
            this.guna2CircleButton35.Animated = true;
            this.guna2CircleButton35.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton35.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton35.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton35.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton35.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton35.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton35.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton35.Name = "guna2CircleButton35";
            this.guna2CircleButton35.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton35.TabStop = false;
            this.guna2CircleButton35.Tag = "3";
            this.guna2CircleButton35.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton35.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton36
            // 
            resources.ApplyResources(this.guna2CircleButton36, "guna2CircleButton36");
            this.guna2CircleButton36.Animated = true;
            this.guna2CircleButton36.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton36.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton36.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton36.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton36.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton36.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton36.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton36.Name = "guna2CircleButton36";
            this.guna2CircleButton36.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton36.TabStop = false;
            this.guna2CircleButton36.Tag = "4";
            this.guna2CircleButton36.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton36.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton37
            // 
            resources.ApplyResources(this.guna2CircleButton37, "guna2CircleButton37");
            this.guna2CircleButton37.Animated = true;
            this.guna2CircleButton37.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton37.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton37.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton37.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton37.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton37.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton37.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton37.Name = "guna2CircleButton37";
            this.guna2CircleButton37.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton37.TabStop = false;
            this.guna2CircleButton37.Tag = "5";
            this.guna2CircleButton37.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton37.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton38
            // 
            resources.ApplyResources(this.guna2CircleButton38, "guna2CircleButton38");
            this.guna2CircleButton38.Animated = true;
            this.guna2CircleButton38.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton38.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton38.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton38.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton38.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton38.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton38.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton38.Name = "guna2CircleButton38";
            this.guna2CircleButton38.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton38.TabStop = false;
            this.guna2CircleButton38.Tag = "6";
            this.guna2CircleButton38.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton38.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton39
            // 
            resources.ApplyResources(this.guna2CircleButton39, "guna2CircleButton39");
            this.guna2CircleButton39.Animated = true;
            this.guna2CircleButton39.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton39.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton39.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton39.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton39.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton39.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton39.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton39.Name = "guna2CircleButton39";
            this.guna2CircleButton39.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton39.TabStop = false;
            this.guna2CircleButton39.Tag = "7";
            this.guna2CircleButton39.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton39.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton40
            // 
            resources.ApplyResources(this.guna2CircleButton40, "guna2CircleButton40");
            this.guna2CircleButton40.Animated = true;
            this.guna2CircleButton40.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton40.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton40.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton40.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton40.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton40.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton40.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton40.Name = "guna2CircleButton40";
            this.guna2CircleButton40.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton40.TabStop = false;
            this.guna2CircleButton40.Tag = "8";
            this.guna2CircleButton40.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton40.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2TextBox4
            // 
            this.guna2TextBox4.Animated = true;
            this.guna2TextBox4.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox4.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox4.BorderRadius = 15;
            this.guna2TextBox4.BorderThickness = 0;
            this.guna2TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox4.DefaultText = "0";
            this.guna2TextBox4.DisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2TextBox4.DisabledState.ForeColor = System.Drawing.Color.SlateBlue;
            this.guna2TextBox4.DisabledState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2TextBox4.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            resources.ApplyResources(this.guna2TextBox4, "guna2TextBox4");
            this.guna2TextBox4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2TextBox4.HoverState.BorderColor = System.Drawing.Color.White;
            this.guna2TextBox4.MaxLength = 3;
            this.guna2TextBox4.Name = "guna2TextBox4";
            this.guna2TextBox4.PasswordChar = '\0';
            this.guna2TextBox4.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2TextBox4.PlaceholderText = "";
            this.guna2TextBox4.SelectedText = "";
            this.guna2TextBox4.TabStop = false;
            this.guna2TextBox4.Tag = "9";
            this.guna2TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2TextBox4.TextChanged += new System.EventHandler(this.FinalNumber_TextChanged);
            this.guna2TextBox4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FinalNumber_MouseClick);
            // 
            // Line4
            // 
            this.Line4.BackColor = System.Drawing.Color.Transparent;
            this.Line4.Controls.Add(this.panel11);
            this.Line4.Controls.Add(this.guna2CircleButton41);
            this.Line4.Controls.Add(this.guna2CircleButton42);
            this.Line4.Controls.Add(this.guna2CircleButton43);
            this.Line4.Controls.Add(this.guna2CircleButton44);
            this.Line4.Controls.Add(this.guna2CircleButton45);
            this.Line4.Controls.Add(this.guna2CircleButton46);
            this.Line4.Controls.Add(this.guna2CircleButton47);
            this.Line4.Controls.Add(this.guna2CircleButton48);
            this.Line4.Controls.Add(this.guna2TextBox6);
            resources.ApplyResources(this.Line4, "Line4");
            this.Line4.Name = "Line4";
            this.Line4.Tag = "4";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.label33);
            this.panel11.Controls.Add(this.label34);
            resources.ApplyResources(this.panel11, "panel11");
            this.panel11.Name = "panel11";
            this.panel11.Tag = "10";
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Name = "label33";
            this.label33.Tag = "1";
            // 
            // label34
            // 
            resources.ApplyResources(this.label34, "label34");
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Name = "label34";
            // 
            // guna2CircleButton41
            // 
            resources.ApplyResources(this.guna2CircleButton41, "guna2CircleButton41");
            this.guna2CircleButton41.Animated = true;
            this.guna2CircleButton41.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton41.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton41.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton41.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton41.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton41.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton41.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton41.Name = "guna2CircleButton41";
            this.guna2CircleButton41.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton41.TabStop = false;
            this.guna2CircleButton41.Tag = "1";
            this.guna2CircleButton41.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton41.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton42
            // 
            resources.ApplyResources(this.guna2CircleButton42, "guna2CircleButton42");
            this.guna2CircleButton42.Animated = true;
            this.guna2CircleButton42.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton42.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton42.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton42.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton42.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton42.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton42.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton42.Name = "guna2CircleButton42";
            this.guna2CircleButton42.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton42.TabStop = false;
            this.guna2CircleButton42.Tag = "2";
            this.guna2CircleButton42.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton42.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton43
            // 
            resources.ApplyResources(this.guna2CircleButton43, "guna2CircleButton43");
            this.guna2CircleButton43.Animated = true;
            this.guna2CircleButton43.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton43.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton43.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton43.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton43.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton43.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton43.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton43.Name = "guna2CircleButton43";
            this.guna2CircleButton43.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton43.TabStop = false;
            this.guna2CircleButton43.Tag = "3";
            this.guna2CircleButton43.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton43.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton44
            // 
            resources.ApplyResources(this.guna2CircleButton44, "guna2CircleButton44");
            this.guna2CircleButton44.Animated = true;
            this.guna2CircleButton44.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton44.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton44.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton44.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton44.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton44.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton44.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton44.Name = "guna2CircleButton44";
            this.guna2CircleButton44.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton44.TabStop = false;
            this.guna2CircleButton44.Tag = "4";
            this.guna2CircleButton44.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton44.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton45
            // 
            resources.ApplyResources(this.guna2CircleButton45, "guna2CircleButton45");
            this.guna2CircleButton45.Animated = true;
            this.guna2CircleButton45.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton45.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton45.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton45.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton45.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton45.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton45.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton45.Name = "guna2CircleButton45";
            this.guna2CircleButton45.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton45.TabStop = false;
            this.guna2CircleButton45.Tag = "5";
            this.guna2CircleButton45.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton45.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton46
            // 
            resources.ApplyResources(this.guna2CircleButton46, "guna2CircleButton46");
            this.guna2CircleButton46.Animated = true;
            this.guna2CircleButton46.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton46.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton46.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton46.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton46.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton46.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton46.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton46.Name = "guna2CircleButton46";
            this.guna2CircleButton46.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton46.TabStop = false;
            this.guna2CircleButton46.Tag = "6";
            this.guna2CircleButton46.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton46.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton47
            // 
            resources.ApplyResources(this.guna2CircleButton47, "guna2CircleButton47");
            this.guna2CircleButton47.Animated = true;
            this.guna2CircleButton47.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton47.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton47.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton47.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton47.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton47.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton47.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton47.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton47.Name = "guna2CircleButton47";
            this.guna2CircleButton47.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton47.TabStop = false;
            this.guna2CircleButton47.Tag = "7";
            this.guna2CircleButton47.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton47.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton48
            // 
            resources.ApplyResources(this.guna2CircleButton48, "guna2CircleButton48");
            this.guna2CircleButton48.Animated = true;
            this.guna2CircleButton48.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton48.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton48.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton48.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton48.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton48.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton48.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton48.Name = "guna2CircleButton48";
            this.guna2CircleButton48.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton48.TabStop = false;
            this.guna2CircleButton48.Tag = "8";
            this.guna2CircleButton48.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton48.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2TextBox6
            // 
            this.guna2TextBox6.Animated = true;
            this.guna2TextBox6.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox6.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox6.BorderRadius = 15;
            this.guna2TextBox6.BorderThickness = 0;
            this.guna2TextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox6.DefaultText = "0";
            this.guna2TextBox6.DisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2TextBox6.DisabledState.ForeColor = System.Drawing.Color.SlateBlue;
            this.guna2TextBox6.DisabledState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2TextBox6.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            resources.ApplyResources(this.guna2TextBox6, "guna2TextBox6");
            this.guna2TextBox6.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2TextBox6.HoverState.BorderColor = System.Drawing.Color.White;
            this.guna2TextBox6.MaxLength = 3;
            this.guna2TextBox6.Name = "guna2TextBox6";
            this.guna2TextBox6.PasswordChar = '\0';
            this.guna2TextBox6.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2TextBox6.PlaceholderText = "";
            this.guna2TextBox6.SelectedText = "";
            this.guna2TextBox6.TabStop = false;
            this.guna2TextBox6.Tag = "9";
            this.guna2TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2TextBox6.TextChanged += new System.EventHandler(this.FinalNumber_TextChanged);
            this.guna2TextBox6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FinalNumber_MouseClick);
            // 
            // Line2
            // 
            this.Line2.BackColor = System.Drawing.Color.Transparent;
            this.Line2.Controls.Add(this.panel3);
            this.Line2.Controls.Add(this.guna2CircleButton9);
            this.Line2.Controls.Add(this.guna2CircleButton10);
            this.Line2.Controls.Add(this.guna2CircleButton11);
            this.Line2.Controls.Add(this.guna2CircleButton12);
            this.Line2.Controls.Add(this.guna2CircleButton13);
            this.Line2.Controls.Add(this.guna2CircleButton14);
            this.Line2.Controls.Add(this.guna2CircleButton15);
            this.Line2.Controls.Add(this.guna2CircleButton16);
            this.Line2.Controls.Add(this.guna2TextBox1);
            resources.ApplyResources(this.Line2, "Line2");
            this.Line2.Name = "Line2";
            this.Line2.Tag = "2";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.label26);
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            this.panel3.Tag = "10";
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Name = "label25";
            this.label25.Tag = "1";
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Name = "label26";
            // 
            // guna2CircleButton9
            // 
            resources.ApplyResources(this.guna2CircleButton9, "guna2CircleButton9");
            this.guna2CircleButton9.Animated = true;
            this.guna2CircleButton9.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton9.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton9.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton9.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton9.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton9.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton9.Name = "guna2CircleButton9";
            this.guna2CircleButton9.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton9.TabStop = false;
            this.guna2CircleButton9.Tag = "1";
            this.guna2CircleButton9.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton9.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton10
            // 
            resources.ApplyResources(this.guna2CircleButton10, "guna2CircleButton10");
            this.guna2CircleButton10.Animated = true;
            this.guna2CircleButton10.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton10.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton10.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton10.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton10.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton10.Name = "guna2CircleButton10";
            this.guna2CircleButton10.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton10.TabStop = false;
            this.guna2CircleButton10.Tag = "2";
            this.guna2CircleButton10.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton10.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton11
            // 
            resources.ApplyResources(this.guna2CircleButton11, "guna2CircleButton11");
            this.guna2CircleButton11.Animated = true;
            this.guna2CircleButton11.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton11.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton11.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton11.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton11.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton11.Name = "guna2CircleButton11";
            this.guna2CircleButton11.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton11.TabStop = false;
            this.guna2CircleButton11.Tag = "3";
            this.guna2CircleButton11.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton11.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton12
            // 
            resources.ApplyResources(this.guna2CircleButton12, "guna2CircleButton12");
            this.guna2CircleButton12.Animated = true;
            this.guna2CircleButton12.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton12.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton12.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton12.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton12.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton12.Name = "guna2CircleButton12";
            this.guna2CircleButton12.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton12.TabStop = false;
            this.guna2CircleButton12.Tag = "4";
            this.guna2CircleButton12.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton12.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton13
            // 
            resources.ApplyResources(this.guna2CircleButton13, "guna2CircleButton13");
            this.guna2CircleButton13.Animated = true;
            this.guna2CircleButton13.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton13.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton13.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton13.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton13.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton13.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton13.Name = "guna2CircleButton13";
            this.guna2CircleButton13.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton13.TabStop = false;
            this.guna2CircleButton13.Tag = "5";
            this.guna2CircleButton13.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton13.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton14
            // 
            resources.ApplyResources(this.guna2CircleButton14, "guna2CircleButton14");
            this.guna2CircleButton14.Animated = true;
            this.guna2CircleButton14.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton14.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton14.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton14.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton14.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton14.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton14.Name = "guna2CircleButton14";
            this.guna2CircleButton14.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton14.TabStop = false;
            this.guna2CircleButton14.Tag = "6";
            this.guna2CircleButton14.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton14.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton15
            // 
            resources.ApplyResources(this.guna2CircleButton15, "guna2CircleButton15");
            this.guna2CircleButton15.Animated = true;
            this.guna2CircleButton15.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton15.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton15.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton15.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton15.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton15.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton15.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton15.Name = "guna2CircleButton15";
            this.guna2CircleButton15.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton15.TabStop = false;
            this.guna2CircleButton15.Tag = "7";
            this.guna2CircleButton15.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton15.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2CircleButton16
            // 
            resources.ApplyResources(this.guna2CircleButton16, "guna2CircleButton16");
            this.guna2CircleButton16.Animated = true;
            this.guna2CircleButton16.BackColor = System.Drawing.Color.Transparent;
            this.guna2CircleButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CircleButton16.DisabledState.BorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton16.DisabledState.CustomBorderColor = System.Drawing.Color.Black;
            this.guna2CircleButton16.DisabledState.FillColor = System.Drawing.Color.SlateBlue;
            this.guna2CircleButton16.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CircleButton16.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2CircleButton16.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2CircleButton16.Name = "guna2CircleButton16";
            this.guna2CircleButton16.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CircleButton16.TabStop = false;
            this.guna2CircleButton16.Tag = "8";
            this.guna2CircleButton16.TextOffset = new System.Drawing.Point(1, 0);
            this.guna2CircleButton16.Click += new System.EventHandler(this.BinButton_Click);
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.Animated = true;
            this.guna2TextBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox1.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox1.BorderRadius = 15;
            this.guna2TextBox1.BorderThickness = 0;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "0";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.SlateBlue;
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            resources.ApplyResources(this.guna2TextBox1, "guna2TextBox1");
            this.guna2TextBox1.ForeColor = System.Drawing.Color.SaddleBrown;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.White;
            this.guna2TextBox1.MaxLength = 3;
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.guna2TextBox1.PlaceholderText = "";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.TabStop = false;
            this.guna2TextBox1.Tag = "9";
            this.guna2TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.guna2TextBox1.TextChanged += new System.EventHandler(this.FinalNumber_TextChanged);
            this.guna2TextBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FinalNumber_MouseClick);
            // 
            // Line1
            // 
            this.Line1.BackColor = System.Drawing.Color.Transparent;
            this.Line1.Controls.Add(this.soucPanel);
            this.Line1.Controls.Add(this.guna2CircleButton7);
            this.Line1.Controls.Add(this.guna2CircleButton8);
            this.Line1.Controls.Add(this.guna2CircleButton5);
            this.Line1.Controls.Add(this.guna2CircleButton6);
            this.Line1.Controls.Add(this.guna2CircleButton3);
            this.Line1.Controls.Add(this.guna2CircleButton4);
            this.Line1.Controls.Add(this.guna2CircleButton2);
            this.Line1.Controls.Add(this.guna2CircleButton1);
            this.Line1.Controls.Add(this.guna2TextBox5);
            resources.ApplyResources(this.Line1, "Line1");
            this.Line1.Name = "Line1";
            this.Line1.Tag = "1";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Name = "label13";
            // 
            // Logo
            // 
            resources.ApplyResources(this.Logo, "Logo");
            this.Logo.Name = "Logo";
            this.Logo.TabStop = false;
            // 
            // TimerLines
            // 
            this.TimerLines.Interval = 1000;
            this.TimerLines.Tick += new System.EventHandler(this.TimerLines_Tick);
            // 
            // Title
            // 
            resources.ApplyResources(this.Title, "Title");
            this.Title.ForeColor = System.Drawing.Color.Gray;
            this.Title.Name = "Title";
            // 
            // Binar
            // 
            this.AllowDrop = true;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Controls.Add(this.Close);
            this.Controls.Add(this.Minimalize);
            this.Controls.Add(this.MovingPanel);
            this.Controls.Add(this.PanelBinSous);
            this.Controls.Add(this.TestPanel);
            this.Controls.Add(this.TestButton);
            this.Controls.Add(this.ZacitProcvicovani);
            this.Controls.Add(this.Logo);
            this.Controls.Add(this.Title);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Binar";
            this.Load += new System.EventHandler(this.Binar_Load);
            this.MovingPanel.ResumeLayout(false);
            this.TestPanel.ResumeLayout(false);
            this.soucPanel.ResumeLayout(false);
            this.soucPanel.PerformLayout();
            this.PanelBinSous.ResumeLayout(false);
            this.PanelBinSous.PerformLayout();
            this.CalculatorPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Obtiznost)).EndInit();
            this.BinDecPanelChooser.ResumeLayout(false);
            this.BinDecPanelChooser.PerformLayout();
            this.Line7.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.Line6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.Line3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.Line5.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.Line4.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.Line2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Line1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox Logo;
        private Guna.UI2.WinForms.Guna2Button ZacitProcvicovani;
        private Guna.UI2.WinForms.Guna2CircleButton Close;
        private Guna.UI2.WinForms.Guna2CircleButton Back;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel MovingPanel;
        private Guna.UI2.WinForms.Guna2CircleButton Minimalize;
        private Guna.UI2.WinForms.Guna2Button TestButton;
        private Guna.UI2.WinForms.Guna2Panel TestPanel;
        private Guna.UI2.WinForms.Guna2Button Test4;
        private Guna.UI2.WinForms.Guna2Button Test3;
        private Guna.UI2.WinForms.Guna2Button Test2;
        private Guna.UI2.WinForms.Guna2Button Test1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox5;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton1;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton2;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton4;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton3;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton6;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton5;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton8;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton7;
        private Guna.UI2.WinForms.Guna2Button BinarStart;
        private System.Windows.Forms.Panel soucPanel;
        private System.Windows.Forms.Label Soucet1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label JmenoCviceni;
        private System.Windows.Forms.TextBox Info;
        private System.Windows.Forms.Panel PanelBinSous;
        private System.Windows.Forms.Panel Line2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton9;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton10;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton11;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton12;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton13;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton14;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton15;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton16;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private System.Windows.Forms.Panel Line1;
        private System.Windows.Forms.Panel Line7;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton49;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton50;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton51;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton52;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton53;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton54;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton55;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton56;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox7;
        private System.Windows.Forms.Panel Line6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton25;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton26;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton27;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton28;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton29;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton30;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton31;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton32;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox3;
        private System.Windows.Forms.Panel Line3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton17;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton18;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton19;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton20;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton21;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton22;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton23;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton24;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private System.Windows.Forms.Panel Line5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton33;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton34;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton35;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton36;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton37;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton38;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton39;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton40;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox4;
        private System.Windows.Forms.Panel Line4;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton41;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton42;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton43;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton44;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton45;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton46;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton47;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton48;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox6;
        private Guna.UI2.WinForms.Guna2ToggleSwitch DecBin;
        private System.Windows.Forms.Panel BinDecPanelChooser;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label38;
        private Guna.UI2.WinForms.Guna2NumericUpDown Obtiznost;
        private System.Windows.Forms.Label Remain;
        private System.Windows.Forms.Label label13;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton63;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton64;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton65;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton60;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton61;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton62;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton59;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton58;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton57;
        private Guna.UI2.WinForms.Guna2Panel CalculatorPanel;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton66;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton67;
        private System.Windows.Forms.Timer TimerLines;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label TimerTest;
        private System.Windows.Forms.Label LimitKliknuti;
        private Guna.UI2.WinForms.Guna2CircleButton guna2CircleButton68;
    }
}

