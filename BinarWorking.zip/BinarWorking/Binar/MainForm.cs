﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Automation;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Media.Effects;
using System.Collections.Generic;
using System.Windows.Media.Animation;
using System.Web.Caching;


namespace Binar
{

    public partial class Binar : Form
    {
        private bool formClosed = false;
        bool stop = false;
        private Point mouseDownLocation;
        bool testee = false;
        int timertest = 0;
        int testmode = 0;
        int testlimitclick = 0;
        bool uspesnosttest = false;


        public Binar()
        {
            InitializeComponent();
            MovingPanel.MouseDown += MovingPanel_MouseDown;
            MovingPanel.MouseMove += MovingPanel_MouseMove;
            MovingPanel.MouseUp += MovingPanel_MouseUp;
            this.FormClosed += Binar_FormClosed;



            this.FormBorderStyle = FormBorderStyle.None;

            GraphicsPath path = new GraphicsPath();

            path.AddArc(0, 0, 80, 80, 180, 90);

            path.AddArc(this.Width - 80, 0, 80, 80, 270, 90);
            path.AddArc(this.Width - 80, this.Height - 80, 80, 80, 0, 90);
            path.AddArc(0, this.Height - 80, 80, 80, 90, 90);

            path.CloseAllFigures();

            this.Region = new Region(path);
        }
        private void Binar_FormClosed(object sender, FormClosedEventArgs e)
        {

            formClosed = true;
        }
        private void MovingPanel_MouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                mouseDownLocation = e.Location;
            }
        }

        private void MovingPanel_MouseMove(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                int deltaX = e.X - mouseDownLocation.X;
                int deltaY = e.Y - mouseDownLocation.Y;
                this.Location = new Point(this.Location.X + deltaX, this.Location.Y + deltaY);
            }
        }

        private void MovingPanel_MouseUp(object sender, MouseEventArgs e)
        {

            mouseDownLocation = Point.Empty;
        }
        private async void Binar_Load(object sender, EventArgs e)
        {


            PanelBinSous.Size = new Size(1250, 700);
            PanelBinSous.Location = new Point(2, 49);

            ZacitProcvicovani.Location = new Point(509, 302);
            TestButton.Location = new Point(509, 390);




            this.Size = new Size(0, this.Size.Height);
            for (int i = 0; i <= 25; i++)
            {
                this.Size = new Size(this.Size.Width + 50, this.Size.Width);

                await Task.Delay(10);
            }
        }
        private async void Close_Click(object sender, EventArgs e)
        {
            for (int i = 0; i <= 11; i++)
            {
                this.Size = this.Size - new Size(200, 120);
                this.Opacity = this.Opacity - 5 / 100.0;
                this.Location = new Point((this.Width - label2.Width) / 2, (this.Height - label2.Height) / 2);
                this.Update();
                await Task.Delay(10);
            }
            Close();
        }

        Point mainposition = new Point(0, 0);
        private async void Minimalize_Click(object sender, EventArgs e)
        {
            int movinx = 10;
            int moviny = 25;

            mainposition = this.Location;
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;
            int x = (screenWidth - this.Width) / 2;
            int y = screenHeight - this.Height;

            for (int i = 0; i <= 20; i++)
            {

                this.Opacity = this.Opacity - i / 100.0;
                if (this.Location.X > x)
                {
                    this.Location = new Point(this.Location.X - movinx, this.Location.Y + moviny);
                }
                else if (this.Location.X < x)
                {
                    this.Location = new Point(this.Location.X + movinx, this.Location.Y + moviny);
                }
                else if (this.Location.X == x)
                {
                    this.Location = new Point(this.Location.X, this.Location.Y + moviny);
                }

                int middle = Math.Abs(this.Location.X - x);
                if (middle < movinx)
                {
                    this.Location = new Point(x, this.Location.Y + moviny);
                }
                await Task.Delay(10);
            }
            this.WindowState = FormWindowState.Minimized;
            this.Opacity = 100;
            this.Location = mainposition;
        }
        int nehotovo = 7;
        private void PanelBinSous_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.Black, 2);

            e.Graphics.DrawRectangle(pen, 46, -1, 55, 764);
            e.Graphics.DrawRectangle(pen, 121, -1, 55, 764);
            e.Graphics.DrawRectangle(pen, 197, -1, 55, 764);
            e.Graphics.DrawRectangle(pen, 277, -1, 55, 764);
            e.Graphics.DrawRectangle(pen, 354, -1, 55, 764);
            e.Graphics.DrawRectangle(pen, 429, -1, 55, 764);
            e.Graphics.DrawRectangle(pen, 505, -1, 55, 764);
            e.Graphics.DrawRectangle(pen, 580, -1, 55, 764);
        }


        bool cooldown = false;
        private async Task Smazani()
        {
            cooldown = true;

            stop = false;
            nehotovo = 7; Remain.Text = Convert.ToString(7 - nehotovo) + "/7";
            line1TIME = 0;
            line2TIME = 0;
            line3TIME = 0;
            line4TIME = 0;
            line5TIME = 0;
            line6TIME = 0;
            line7TIME = 0;

            CalculatorPanel.Visible = false;
            var LinesNumbers = PanelBinSous.Controls.OfType<Panel>().ToList();
            for (int Addingline = 7; Addingline >= 0; Addingline--)
            {
                foreach (var LinesNumber in LinesNumbers)
                {
                    if (int.TryParse(Convert.ToString(LinesNumber.Tag), out int TAG) && TAG == Addingline)
                    {
                        var Buttons = LinesNumber.Controls.OfType<Guna2CircleButton>().ToList();
                        var TextBoxes = LinesNumber.Controls.OfType<Guna2TextBox>().ToList();
                        var SoucPanels = LinesNumber.Controls.OfType<Panel>().ToList();

                        for (int LineTag = 10; LineTag >= 1; LineTag--)
                        {


                            foreach (var SoucPanel in SoucPanels)
                            {
                                if (int.TryParse(Convert.ToString(SoucPanel.Tag), out int TAGE) && TAGE == LineTag)
                                {
                                    await Task.Delay(new Random().Next(1, 51));
                                    SoucPanel.Visible = false;
                                }
                            }

                            foreach (var TextBox in TextBoxes)
                            {
                                if (int.TryParse(Convert.ToString(TextBox.Tag), out int TAGE) && TAGE == LineTag)
                                {
                                    await Task.Delay(new Random().Next(1, 51));
                                    TextBox.Visible = false;
                                }
                            }

                            foreach (var Button in Buttons)
                            {
                                if (int.TryParse(Convert.ToString(Button.Tag), out int TAGE) && TAGE == LineTag)
                                {
                                    await Task.Delay(new Random().Next(1, 51));
                                    Button.Visible = false;
                                }
                            }

                        }

                        LinesNumber.Visible = false;
                    }
                }
            }

            for (int Addingline = 7; Addingline >= 0; Addingline--)
            {
                foreach (var LinesNumber in LinesNumbers)
                {
                    if (int.TryParse(Convert.ToString(LinesNumber.Tag), out int TAG) && TAG == Addingline)
                    {
                        var Buttons = LinesNumber.Controls.OfType<Guna2CircleButton>().ToList();
                        var TextBoxes = LinesNumber.Controls.OfType<Guna2TextBox>().ToList();
                        var SoucPanels = LinesNumber.Controls.OfType<Panel>().ToList();

                        for (int LineTag = 10; LineTag >= 1; LineTag--)
                        {


                            foreach (var SoucPanel in SoucPanels)
                            {
                                if (int.TryParse(Convert.ToString(SoucPanel.Tag), out int TAGE) && TAGE == LineTag)
                                {

                                    SoucPanel.Visible = false;
                                }
                            }

                            foreach (var TextBox in TextBoxes)
                            {
                                if (int.TryParse(Convert.ToString(TextBox.Tag), out int TAGE) && TAGE == LineTag)
                                {

                                    TextBox.Visible = false;
                                }
                            }

                            foreach (var Button in Buttons)
                            {
                                if (int.TryParse(Convert.ToString(Button.Tag), out int TAGE) && TAGE == LineTag)
                                {

                                    Button.Visible = false;
                                }
                            }

                        }

                        LinesNumber.Visible = false;
                    }
                }
            }
            await Task.Delay(3500); cooldown = false;

        }


        private async void BinButton_Click(object sender, EventArgs e)
        {
            Guna2CircleButton tlacitko = (Guna2CircleButton)sender;
            CalculatorPanel.Visible = false;
            Panel panel = tlacitko.Parent as Panel;
            if (panel != null)
            {
                int plus;
                if (!int.TryParse(tlacitko.AccessibleDescription, out plus))
                {
                    MessageBox.Show("Invalid tag value for button.");
                    return;
                }
                if (testee)
                {
                    if (testlimitclick<=0)
                        {
                        uspesnosttest = false;
                        TestKonec();
                    }
                    else
                    {
                    testlimitclick -= 1;
                    LimitKliknuti.Text = "Limit Kliknutí: " + testlimitclick;
                    }
                    
                    
                }

                if (tlacitko.Text == "0")
                {
                    tlacitko.Text = "1";
                    tlacitko.FillColor = Color.FromArgb(255, 192, 128);
                    tlacitko.ForeColor = Color.SaddleBrown;
                }
                else if (tlacitko.Text == "1")
                {
                    tlacitko.Text = "0";

                    tlacitko.FillColor = Color.SaddleBrown;
                    tlacitko.ForeColor = Color.FromArgb(255, 192, 128);
                }

                var textBoxes = panel.Controls.OfType<Guna2TextBox>().ToList();
                var buttons = panel.Controls.OfType<Guna2CircleButton>().ToList();
                var panels = panel.Controls.OfType<Panel>().ToList();
                int ans = 0;
                


                foreach (var GroupButton in buttons)
                {
                    if (GroupButton.Text == "1" && int.TryParse(GroupButton.AccessibleDescription, out plus))
                    {
                        ans += plus;
                    }
                }

                foreach (var SoucPanel in panels)
                {

                    var AnsLabels = SoucPanel.Controls.OfType<Label>().ToList();
                    foreach (var Label in AnsLabels)
                    {
                        if (Convert.ToInt32(Label.Tag) == 1) {
                            Label.Text = Convert.ToString(ans);
                            break;
                        }
                    }
                    break;

                }

                foreach (var GroupTexboxes in textBoxes)
                {

                    if (int.TryParse(GroupTexboxes.Text, out int value) && value == ans)
                    {
                       
                        nehotovo--;
                        Remain.Text = Convert.ToString(7 - nehotovo) + "/7";
                        if (!testee)
                        {
                            switch (panel.Tag)
                            {
                                case "7":

                                    line7TIMED = line7TIME;
                                    line6TIME = 0;
                                    line5TIME = 0;
                                    line4TIME = 0;
                                    line3TIME = 0;
                                    line2TIME = 0;
                                    line1TIME = 0;
                                    break;
                                case "6":

                                    line6TIMED = line6TIME;
                                    line7TIME = 0;
                                    line5TIME = 0;
                                    line4TIME = 0;
                                    line3TIME = 0;
                                    line2TIME = 0;
                                    line1TIME = 0;
                                    break;
                                case "5":

                                    line5TIMED = line5TIME;
                                    line7TIME = 0;
                                    line6TIME = 0;
                                    line4TIME = 0;
                                    line3TIME = 0;
                                    line2TIME = 0;
                                    line1TIME = 0;
                                    break;
                                case "4":

                                    line4TIMED = line4TIME;
                                    line7TIME = 0;
                                    line6TIME = 0;
                                    line5TIME = 0;
                                    line3TIME = 0;
                                    line2TIME = 0;
                                    line1TIME = 0;
                                    break;
                                case "3":

                                    line3TIMED = line3TIME;
                                    line7TIME = 0;
                                    line6TIME = 0;
                                    line5TIME = 0;
                                    line4TIME = 0;
                                    line2TIME = 0;
                                    line1TIME = 0;
                                    break;
                                case "2":

                                    line2TIMED = line2TIME;
                                    line7TIME = 0;
                                    line6TIME = 0;
                                    line5TIME = 0;
                                    line4TIME = 0;
                                    line3TIME = 0;
                                    line1TIME = 0;
                                    break;
                                case "1":

                                    line1TIMED = line1TIME;
                                    line7TIME = 0;
                                    line6TIME = 0;
                                    line5TIME = 0;
                                    line4TIME = 0;
                                    line3TIME = 0;
                                    line2TIME = 0;
                                    break;
                            }
                        }
                        foreach (var GroupButton in buttons)
                        {
                            GroupButton.FillColor = Color.FromArgb(192, 255, 192);
                            GroupButton.ForeColor = Color.DarkGreen;
                        }
                        GroupTexboxes.DisabledState.FillColor = Color.FromArgb(192, 255, 192);
                        GroupTexboxes.DisabledState.ForeColor = Color.DarkGreen;
                        GroupTexboxes.FillColor = Color.FromArgb(192, 255, 192);
                        GroupTexboxes.ForeColor = Color.DarkGreen;

                        await Task.Delay(1000);
                        panel.Visible = false;
                        GroupTexboxes.Visible = false;
                        GroupTexboxes.Text = string.Empty;
                        foreach (var GroupButton in buttons)
                        {

                            GroupButton.Visible = false;

                        }

                        foreach (var SoucPanel in panels)
                        {

                            var AnsLabels = SoucPanel.Controls.OfType<Label>().ToList();
                            SoucPanel.Visible = false;
                            foreach (var Label in AnsLabels)
                            {

                                Label.Text = "0";

                            }

                        }
                        if (nehotovo <= 0)
                        {
                            if (!testee)
                            {
                                KonecGraf();
                            }
                            else
                            {
                                uspesnosttest = true;
                                TestKonec();
                            }



                        }
                    }

                }
            }

        }

        private async void FinalNumber_TextChanged(object sender, EventArgs e)
        {
            Guna2TextBox finalNumber = (Guna2TextBox)sender;

            try
            {
                if (!int.TryParse(finalNumber.Text, out int enteredValue) || enteredValue < 0)
                {
                    finalNumber.Text = string.Empty;
                    return;
                }

                int clampedValue = Math.Min(enteredValue, 255);

                finalNumber.Text = clampedValue.ToString();


                finalNumber.SelectionStart = finalNumber.Text.Length;

                Panel panel = finalNumber.Parent as Panel;
                if (panel != null)
                {

                    var buttons = panel.Controls.OfType<Guna2CircleButton>().ToList();
                    int ans = 0;




                    foreach (var groupButton in buttons)
                    {
                        if (groupButton.Text == "1")
                        {
                            int plus = Convert.ToInt32(groupButton.AccessibleDescription);
                            ans += plus;
                        }
                    }

                    


                    if (clampedValue == ans)
                    {

                       nehotovo--;
                        Remain.Text = Convert.ToString(7 - nehotovo) + "/7";
                        if (!testee)
                        {
                        switch (panel.Tag)
                        {
                            case "7":

                                line7TIMED = line7TIME;
                                line6TIME = 0;
                                line5TIME = 0;
                                line4TIME = 0;
                                line3TIME = 0;
                                line2TIME = 0;
                                line1TIME = 0;
                                break;
                            case "6":

                                line6TIMED = line6TIME;
                                line7TIME = 0;
                                line5TIME = 0;
                                line4TIME = 0;
                                line3TIME = 0;
                                line2TIME = 0;
                                line1TIME = 0;
                                break;
                            case "5":

                                line5TIMED = line5TIME;
                                line7TIME = 0;
                                line6TIME = 0;
                                line4TIME = 0;
                                line3TIME = 0;
                                line2TIME = 0;
                                line1TIME = 0;
                                break;
                            case "4":

                                line4TIMED = line4TIME;
                                line7TIME = 0;
                                line6TIME = 0;
                                line5TIME = 0;
                                line3TIME = 0;
                                line2TIME = 0;
                                line1TIME = 0;
                                break;
                            case "3":

                                line3TIMED = line3TIME;
                                line7TIME = 0;
                                line6TIME = 0;
                                line5TIME = 0;
                                line4TIME = 0;
                                line2TIME = 0;
                                line1TIME = 0;
                                break;
                            case "2":

                                line2TIMED = line2TIME;
                                line7TIME = 0;
                                line6TIME = 0;
                                line5TIME = 0;
                                line4TIME = 0;
                                line3TIME = 0;
                                line1TIME = 0;
                                break;
                            case "1":

                                line1TIMED = line1TIME;
                                line7TIME = 0;
                                line6TIME = 0;
                                line5TIME = 0;
                                line4TIME = 0;
                                line3TIME = 0;
                                line2TIME = 0;
                                break;
                        } 
                        }
                        foreach (var groupButton in buttons)
                        {

                            groupButton.DisabledState.FillColor = Color.FromArgb(192, 255, 192);
                            groupButton.DisabledState.ForeColor = Color.DarkGreen;
                        }
                        finalNumber.FillColor = Color.FromArgb(192, 255, 192);
                        finalNumber.ForeColor = Color.DarkGreen;

                        await Task.Delay(1000);
                        panel.Visible = false;
                        finalNumber.Visible = false;
                        foreach (var groupButton in buttons)
                        {
                            
                            groupButton.Visible = false;
                            finalNumber.Text = string.Empty;


                        }
                        if (nehotovo <= 0)
                        {
                            if (!testee)
                            {
                                KonecGraf();
                            }
                            else
                            {
                                uspesnosttest = true;
                                TestKonec();
                            }

                        }
                        //Guna2CirclePictureBox effect = new Guna2CirclePictureBox();
                        //effect.Size = new Size(0, panel.Height);
                        //effect.Location = new Point(panel.Location.X + (panel.Width - effect.Width) / 2, panel.Location.Y + (panel.Height - effect.Height) / 2);
                        //effect.FillColor = Color.Lime;
                        //PanelBinSous.Controls.Add(effect);

                        //effect.BringToFront();

                        //int max = 255;

                        //for (int i = 0; i <= 255; i++)
                        //{
                        //    effect.Size = new Size(i * 70, panel.Height - i * 3);
                        //    max = max - i;

                        //    effect.FillColor = Color.FromArgb(max, Color.Lime);

                        //    effect.Location = new Point(panel.Location.X + (panel.Width - effect.Width) / 2 - 120, panel.Location.Y + (panel.Height - effect.Height) / 2);

                        //    if (max <= 2) { break; }
                        //    PanelBinSous.Update();
                        //    effect.Update();

                        //    await Task.Delay(1);
                        //}

                        //this.Controls.Remove(effect);
                        //effect.Dispose();



                    }

                }
            }
            catch (Exception)
            {

            }
        }





        private async void BinarStart_Click(object sender, EventArgs e)
        {
            if (!cooldown)
            {
                CalculatorPanel.Visible = false;
                label24.Text = "Součet"; label26.Text = "Součet"; label28.Text = "Součet"; label34.Text = "Součet"; label32.Text = "Součet"; label30.Text = "Součet"; label37.Text = "Součet";
                if (stop == false)
                { cooldown = true;
                    BinarStart.Text = "...";
                    stop = true;
                    ProblikniPanel();
                    Info.Visible = false;
                    TimerLines.Enabled = true;
                    await Task.Delay(3500);
                    BinarStart.Text = "Stop";
                    cooldown = false;
                    
                }
                else
                {
                    BinarStart.Text = "...";
                    stop = false;
                    if (testee)
                    {
                        switch (testmode)
                        {
                            case 1:

                                timertest = 5 * 60;
                                TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                                Obtiznost.Value = 4;

                                break;
                            case 2:

                                timertest = 6 * 60;
                                TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                                Obtiznost.Value = 3;
                                break;
                            case 3:

                                timertest = 8 * 60;
                                TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                                Obtiznost.Value = 2;
                                break;
                            case 4:

                                timertest = 10 * 60;
                                TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                                Obtiznost.Value = 1;
                                break;

                        }
                        TimerTest.Visible = true;
                        BinDecPanelChooser.Visible = false;
                        label38.Visible = false;
                        Obtiznost.Visible = false;
                        LimitKliknuti.Visible = true;
                        LimitKliknuti.Text = "Limit kliknutí: ⍉";
                        testlimitclick = 0;
                        DecBin.Checked = false;
                        Obtiznost.Value = 1;
                    }

                    Smazani(); cooldown = true;
                    await Task.Delay(3500);
                    BinarStart.Text = "Start";
                    cooldown = false;

                   
                }
               

            }
        }


        private async Task ProblikniPanel()
        {

           

                int MaxCombinations = Convert.ToInt32(Obtiznost.Value) * Convert.ToInt32(Obtiznost.Value) * 8;
                List<string> vybranaCisla = new List<string>();
                List<string> vybranaCislaDec = new List<string>();
            int addingteste = 0;
                for (int Addingline = 0; Addingline <= 7; Addingline++)
                {
                if (testee)
                {
                    addingteste += 1;
                    DecBin.Checked = addingteste >= new Random().Next(5, 7);
                }
                    if (!DecBin.Checked)
                    {
                    //Dec To Bin
                    if (testee)
                    {
                        switch (testmode)
                        {
                            case 1:
                                testlimitclick += 10;
                                break;
                            case 2:
                                testlimitclick += 13;
                                break;
                            case 3:
                                testlimitclick += 15;
                                break;
                            case 4:
                                testlimitclick += 25;
                                break;

                        }
                        
                        LimitKliknuti.Text = "Limit kliknutí: " + testlimitclick;
                    }
                    var LinesNumbers = PanelBinSous.Controls.OfType<Panel>().ToList();
                        foreach (var LinesNumber in LinesNumbers)
                        {
                            if (int.TryParse(Convert.ToString(LinesNumber.Tag), out int TAG) && TAG == Addingline)
                            {
                                LinesNumber.Visible = true;
                                var Buttons = LinesNumber.Controls.OfType<Guna2CircleButton>().ToList();
                                var TextBoxes = LinesNumber.Controls.OfType<Guna2TextBox>().ToList();
                                var SoucPanels = LinesNumber.Controls.OfType<Panel>().ToList();
                                int LineTag = 0;
                                foreach (var Button in Buttons)
                                {
                                    LineTag++;
                                    if (int.TryParse(Convert.ToString(Button.Tag), out int TAGE) && TAGE == LineTag)
                                    {
                                        await Task.Delay(new Random().Next(1, 51));


                                        Button.Text = Convert.ToString(0);

                                        Button.Visible = true;
                                        Button.Enabled = true;


                                        if (Button.Text == "1")
                                        {
                                            Button.FillColor = Color.FromArgb(255, 192, 128);
                                            Button.ForeColor = Color.SaddleBrown;
                                        }
                                        else if (Button.Text == "0")
                                        {
                                            Button.FillColor = Color.SaddleBrown;
                                            Button.ForeColor = Color.FromArgb(255, 192, 128);
                                        }
                                    }

                                }

                                foreach (var TextBox in TextBoxes)
                                {
                                    LineTag++;


                                    List<int> selectedNumbersDec = new List<int>();


                                    Random rndDec = new Random();
                                    VybiraniRadkuDec(vybranaCislaDec, selectedNumbersDec, rndDec);
                                    if (int.TryParse(Convert.ToString(TextBox.Tag), out int TAGE) && TAGE == LineTag)
                                    {
                                        await Task.Delay(new Random().Next(1, 51));

                                        TextBox.Text = Convert.ToString(selectedNumbersDec.Last());

                                        TextBox.Visible = true;
                                        TextBox.Enabled = false;

                                        TextBox.FillColor = Color.FromArgb(255, 192, 128);
                                        TextBox.ForeColor = Color.SaddleBrown;

                                        TextBox.DisabledState.FillColor = Color.FromArgb(192, 192, 255);
                                        TextBox.DisabledState.ForeColor = Color.SlateBlue;

                                       
                                    }
                                }
                                foreach (var SoucPanel in SoucPanels)
                                {
                                    LineTag++;

                                    if (int.TryParse(Convert.ToString(SoucPanel.Tag), out int TAGE) && TAGE == LineTag)
                                    {
                                        await Task.Delay(new Random().Next(1, 51));
                                        SoucPanel.Visible = !testee;

                                    }
                                }
                            }
                        }

                    }
                    else
                    {
                        //Bin To Dec
                        
                        var LinesNumbers = PanelBinSous.Controls.OfType<Panel>().ToList();
                        foreach (var LinesNumber in LinesNumbers)
                        {
                            if (int.TryParse(Convert.ToString(LinesNumber.Tag), out int TAG) && TAG == Addingline)
                            {
                                LinesNumber.Visible = true;
                                var Buttons = LinesNumber.Controls.OfType<Guna2CircleButton>().ToList();
                                var TextBoxes = LinesNumber.Controls.OfType<Guna2TextBox>().ToList();
                                var SoucPanels = LinesNumber.Controls.OfType<Panel>().ToList();
                                int LineTag = 0;

                                int ONE_ZERO_randomer = new Random().Next(0, 2);


                                int x = Convert.ToInt32(Obtiznost.Value);

                                List<int> selectedNumbers = new List<int>();


                                Random rnd = new Random();

                                VybiraniRadku(vybranaCisla, selectedNumbers, rnd, x);

                                MaxCombinations--;
                                if (MaxCombinations <= 0)
                                {
                                    MaxCombinations = Convert.ToInt32(Obtiznost.Value) * Convert.ToInt32(Obtiznost.Value) * 8;
                                    vybranaCisla.Clear();
                                }
                                foreach (var Button in Buttons)
                                {
                                    LineTag++;
                                    if (int.TryParse(Convert.ToString(Button.Tag), out int TAGE) && TAGE == LineTag)
                                    {
                                        await Task.Delay(new Random().Next(1, 51));


                                        if (selectedNumbers.Contains(LineTag))
                                        {
                                            Button.Text = ONE_ZERO_randomer.ToString();
                                        }
                                        else
                                        {
                                            Button.Text = (ONE_ZERO_randomer == 1 ? "0" : "1");
                                        }

                                        Button.Visible = true;
                                        Button.Enabled = false;

                                        if (Button.Text == "1")
                                        {
                                            Button.DisabledState.FillColor = Color.FromArgb(192, 192, 255);
                                            Button.DisabledState.ForeColor = Color.SlateBlue;
                                        }
                                        else if (Button.Text == "0")
                                        {
                                            Button.DisabledState.FillColor = Color.SlateBlue;
                                            Button.DisabledState.ForeColor = Color.FromArgb(192, 192, 255);
                                        }
                                    }
                                }

                                foreach (var TextBox in TextBoxes)
                                {
                                    LineTag++;

                                    if (int.TryParse(Convert.ToString(TextBox.Tag), out int TAGE) && TAGE == LineTag)
                                    {
                                        await Task.Delay(new Random().Next(1, 51));
                                        TextBox.Text = null;
                                        TextBox.Visible = true;
                                        TextBox.Enabled = true;

                                        TextBox.FillColor = Color.FromArgb(255, 192, 128);
                                        TextBox.ForeColor = Color.SaddleBrown;

                                        TextBox.DisabledState.FillColor = Color.FromArgb(192, 192, 255);
                                        TextBox.DisabledState.ForeColor = Color.SlateBlue;

                                    }
                                }
                                foreach (var SoucPanel in SoucPanels)
                                {
                                    LineTag++;

                                    if (int.TryParse(Convert.ToString(SoucPanel.Tag), out int TAGE) && TAGE == LineTag)
                                    {
                                        await Task.Delay(new Random().Next(1, 51));
                                        SoucPanel.Visible = false;

                                    }
                                }
                            }
                        }
                    

                }

            }
        }

        static void KontrolaRadku(List<String> vybranaCisla, List<int> selectedNumbers, Random rnd, int x)
        {

            for (int i = 0; i < vybranaCisla.Count; i++)
            {
                for (int j = i + 1; j < vybranaCisla.Count; j++)
                {
                    if (vybranaCisla[i] == vybranaCisla[j])
                    {
                        vybranaCisla.RemoveAt(j);
                        selectedNumbers.Clear();
                        VybiraniRadku(vybranaCisla, selectedNumbers, rnd, x);
                        j--;

                    }
                }
            }
        }

        static void VybiraniRadku(List<String> vybranaCisla, List<int> selectedNumbers, Random rnd, int x)
        {

            while (selectedNumbers.Count < x)
            {
                int randomNumber = rnd.Next(1, 9);

                if (!selectedNumbers.Contains(randomNumber))
                {
                    selectedNumbers.Add(randomNumber);
                }
            }
            string cislaOddelenaCarkami = string.Join(", ", selectedNumbers);
            vybranaCisla.Add(cislaOddelenaCarkami);

            KontrolaRadku(vybranaCisla, selectedNumbers, rnd, x);

        }
        static void KontrolaRadkuDec(List<String> vybranaCislaDec, List<int> selectedNumbersDec, Random rndDec)
        {

            for (int i = 0; i < vybranaCislaDec.Count; i++)
            {
                for (int j = i + 1; j < vybranaCislaDec.Count; j++)
                {
                    if (vybranaCislaDec[i] == vybranaCislaDec[j])
                    {
                        vybranaCislaDec.RemoveAt(j);
                        selectedNumbersDec.Clear();
                        VybiraniRadkuDec(vybranaCislaDec, selectedNumbersDec, rndDec);

                        j--;

                    }
                }
            }
        }
        static void VybiraniRadkuDec(List<String> vybranaCislaDec, List<int> selectedNumbersDec, Random rndDec)
        {

            selectedNumbersDec.Add(rndDec.Next(1, 256));

            string cislaOddelenaCarkami = string.Join(", ", selectedNumbersDec);
            vybranaCislaDec.Add(cislaOddelenaCarkami);

            KontrolaRadkuDec(vybranaCislaDec, selectedNumbersDec, rndDec);

        }

        private void binartextbox_enter(object sender, EventArgs e)
        {
            Guna2TextBox texboxee = (Guna2TextBox)sender;
            if (texboxee.AccessibleName == "disabled")
            {
                this.ActiveControl = null;
            }

        }



        ///-----------------------------------------------------------------------------------------------------------------------------------------------
        private async void Zacit_Click(object sender, EventArgs e)
        {
            Guna2Button Cviceni = (Guna2Button)sender;
            if (Cviceni.AccessibleDescription == "Test")
            {
                testee = true;
                testmode = Convert.ToInt32(Cviceni.AccessibleName);

                switch (testmode)
                {
                    case 1:

                        timertest = 5 * 60;
                        TimerTest.Text = "Zbývá: " +timertest.ToString()+" s";
                        Obtiznost.Value = 4;

                       break;
                    case 2:

                        timertest = 6 * 60;
                        TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                        Obtiznost.Value = 3;
                        break;
                    case 3:

                        timertest = 8 * 60;
                        TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                        Obtiznost.Value = 2;
                        break;
                    case 4:

                        timertest = 10 * 60;
                        TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                        Obtiznost.Value = 1;
                        break;

                }
                TimerTest.Visible =true;
                BinDecPanelChooser.Visible = false;
                label38.Visible = false;
                Obtiznost.Visible = false;
                LimitKliknuti.Visible = true;
                LimitKliknuti.Text = "Limit kliknutí: ⍉";
                testlimitclick = 0;
            }
            else
            {

                TimerTest.Visible = false;
                LimitKliknuti.Visible = false;
                testee = false;
                TimerTest.Text = null;
                LimitKliknuti.Text = null;
                testlimitclick = 0;
                timertest = 0; 
                testmode = 0;
                BinDecPanelChooser.Visible = true;

            }

            JmenoCviceni.Text = Cviceni.Text;
            TestButton.Visible = false;
            TestPanel.Visible = false;
            PanelBinSous.Visible = true;
            Back.Visible = true;
            Back.Size = new Size(0, 0);
            ZacitProcvicovani.Visible = false;

            Back.Location = new Point(Back.Location.X + 25, Back.Location.Y + 25);
            PanelBinSous.Size = new Size(1250, 0);
            for (int i = 0; i <= 10; i++)
            {
                Back.Size = new Size(i * 5, i * 5);
                PanelBinSous.Size = new Size(1250, i * 70);
                Back.Location = new Point((Back.Location.X - i / 2), (Back.Location.Y - i / 2));
                await Task.Delay(10);

            }

            Back.Location = new Point(144, 37);
        }


        private async void TestButton_Click(object sender, EventArgs e)
        {
            if (!TestPanel.Visible)
            {
                TestPanel.Visible = true;
            }
            else
            {
                TestPanel.Visible = false;
            }

        }
        private async void Back_Click(object sender, EventArgs e)
        {
            stop = false;
            Smazani();
            BinarStart.Text = "Start";


            TimerTest.Visible = false;
            LimitKliknuti.Visible = false;
            testee = false;
            TimerTest.Text = null;
            LimitKliknuti.Text = null;
            testlimitclick = 0;
            timertest = 0;
            testmode = 0;
            BinDecPanelChooser.Visible = true;

            

            for (int i = 0; i <= 10; i++)
            {
                Back.Size = new Size(Back.Width - i * 5, Back.Height - i * 5);
                PanelBinSous.Size = new Size(1250, PanelBinSous.Height - i * 70);
                await Task.Delay(10);

            }
            Back.Visible = false;
            Back.Size = new Size(50, 50);

            PanelBinSous.Visible = false;
            PanelBinSous.Size = new Size(1250, 700);



            ZacitProcvicovani.Visible = true;

            TestButton.Visible = true;


        }









        private void Info_MouseEnter(object sender, EventArgs e)
        {
            Info.Size = new Size(417, 392);
            Info.ScrollBars = ScrollBars.Vertical;
            Info.Location = new Point(819, 279);

        }

        private void Info_MouseLeave(object sender, EventArgs e)
        {
            Info.Size = new Size(36, 31);
            Info.ScrollBars = ScrollBars.None;
            Info.Location = new Point(1171, 640);
        }


        Guna2TextBox FinalNumberTextbox;
        private void FinalNumber_MouseClick(object sender, MouseEventArgs e)
        {
            FinalNumberTextbox = (Guna2TextBox)sender;
            CalculatorPanel.Visible = true;

        }
        private void CalculatorButton_Click(object sender, EventArgs e)
        {
            Guna2CircleButton Button = (Guna2CircleButton)sender;
            if (FinalNumberTextbox != null && FinalNumberTextbox is Guna2TextBox && CalculatorPanel.Visible)
            {
                if (Button.Text != "⌫" & Button.Text != "C")
                {
                    FinalNumberTextbox.Text = FinalNumberTextbox.Text + Button.Text;
                }
                else if (Button.Text == "⌫")
                {
                    if (!string.IsNullOrEmpty(FinalNumberTextbox.Text))
                    {
                       
                        FinalNumberTextbox.Text = FinalNumberTextbox.Text.Substring(0, FinalNumberTextbox.Text.Length - 1);
                    }
                }
                else if (Button.Text == "C")
                {
                    
                    FinalNumberTextbox.Text = "";
                }
            }
        }
        private async Task TestKonec()
        {
            Smazani();
            TestEndingForm testEndingForm = new TestEndingForm();
            testEndingForm.Owner = this;
            testEndingForm.TopMost = true;
            testEndingForm.StartPosition = FormStartPosition.CenterParent;
            GraphicsPath pathe = new GraphicsPath();
            pathe.AddArc(0, 0, 80, 80, 180, 90);

            pathe.AddArc(testEndingForm.Width - 80, 0, 80, 80, 270, 90);
            pathe.AddArc(testEndingForm.Width - 80, testEndingForm.Height - 80, 80, 80, 0, 90);
            pathe.AddArc(0, testEndingForm.Height - 80, 80, 80, 90, 90);

            pathe.CloseAllFigures();
            testEndingForm.Region = new Region(pathe);
            

            testEndingForm.JmenoCviceni.Text = JmenoCviceni.Text;
            if (uspesnosttest)
            {
                testEndingForm.Uspesnost.Text = "Uspěl";
                testEndingForm.Uspesnost.ForeColor = Color.LightGreen;
            }
            else
            {
                testEndingForm.Uspesnost.Text = "Neuspěl";
                testEndingForm.Uspesnost.ForeColor = Color.Red;
            }
            testEndingForm.ShowDialog();

            switch (testmode)
            {
                case 1:

                    timertest = 5 * 60;
                    TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                    Obtiznost.Value = 4;

                    break;
                case 2:

                    timertest = 6 * 60;
                    TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                    Obtiznost.Value = 3;
                    break;
                case 3:

                    timertest = 8 * 60;
                    TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                    Obtiznost.Value = 2;
                    break;
                case 4:

                    timertest = 10 * 60;
                    TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                    Obtiznost.Value = 1;
                    break;

            }
            TimerTest.Visible = true;
            BinDecPanelChooser.Visible = false;
            label38.Visible = false;
            Obtiznost.Visible = false;
            LimitKliknuti.Visible = true;
            LimitKliknuti.Text = "Limit kliknutí: ⍉";
            testlimitclick = 0;
            
            nehotovo = 7; Remain.Text = Convert.ToString(7 - nehotovo) + "/7";
            stop = false;
            BinarStart.Text = "Start";
            uspesnosttest = false;

        }

        int historie = 0;
        
       
        private async Task KonecGraf()
        {

            TimerLines.Enabled = false;
            EndingForm endingForm = new EndingForm();

            historie++;
            endingForm.Tag = historie.ToString();
            await Mezipamet.PridatHistoriiAsync(

            historie, 
            line1TIMED, 
            line2TIMED,
            line3TIMED, 
            line4TIMED, 
            line5TIMED, 
            line6TIMED, 
            line7TIMED  

                    );

            endingForm.Owner = this;
            endingForm.TopMost = true;
            endingForm.StartPosition = FormStartPosition.CenterParent;
            GraphicsPath pathe = new GraphicsPath();
            pathe.AddArc(0, 0, 80, 80, 180, 90);

            pathe.AddArc(endingForm.Width - 80, 0, 80, 80, 270, 90);
            pathe.AddArc(endingForm.Width - 80, endingForm.Height - 80, 80, 80, 0, 90);
            pathe.AddArc(0, endingForm.Height - 80, 80, 80, 90, 90);

            pathe.CloseAllFigures();
            endingForm.Region = new Region(pathe);


            int maxValue = Math.Max(line1TIMED, Math.Max(line2TIMED, Math.Max(line3TIMED, Math.Max(line4TIMED, Math.Max(line5TIMED, Math.Max(line6TIMED, line7TIMED))))));

            
            endingForm.G1.AccessibleDescription = line1TIMED.ToString();
            endingForm.G2.AccessibleDescription = line2TIMED.ToString();
            endingForm.G3.AccessibleDescription = line3TIMED.ToString();
            endingForm.G4.AccessibleDescription = line4TIMED.ToString();
            endingForm.G5.AccessibleDescription = line5TIMED.ToString();
            endingForm.G6.AccessibleDescription = line6TIMED.ToString();
            endingForm.G7.AccessibleDescription = line7TIMED.ToString();

            endingForm.G1.Height = 300 * line1TIMED / maxValue;
            endingForm.G2.Height = 300 * line2TIMED / maxValue;
            endingForm.G3.Height = 300 * line3TIMED / maxValue;
            endingForm.G4.Height = 300 * line4TIMED / maxValue;
            endingForm.G5.Height = 300 * line5TIMED / maxValue;
            endingForm.G6.Height = 300 * line6TIMED / maxValue;
            endingForm.G7.Height = 300 * line7TIMED / maxValue;


            endingForm.G1.Location = new Point(endingForm.G1.Location.X, 465 - (300 * line1TIMED / maxValue));
            endingForm.G2.Location = new Point(endingForm.G2.Location.X, 465 - (300 * line2TIMED / maxValue));
            endingForm.G3.Location = new Point(endingForm.G3.Location.X, 465 - (300 * line3TIMED / maxValue));
            endingForm.G4.Location = new Point(endingForm.G4.Location.X, 465 - (300 * line4TIMED / maxValue));
            endingForm.G5.Location = new Point(endingForm.G5.Location.X, 465 - (300 * line5TIMED / maxValue));
            endingForm.G6.Location = new Point(endingForm.G6.Location.X, 465 - (300 * line6TIMED / maxValue));
            endingForm.G7.Location = new Point(endingForm.G7.Location.X, 465 - (300 * line7TIMED / maxValue));


            endingForm.T1.Location = new Point(endingForm.G1.Right - endingForm.T1.Width * 1, endingForm.G1.Top - endingForm.T1.Height * 1);
            endingForm.T2.Location = new Point(endingForm.G2.Right - endingForm.T1.Width * 1, endingForm.G2.Top - endingForm.T1.Height * 1);
            endingForm.T3.Location = new Point(endingForm.G3.Right - endingForm.T1.Width * 1, endingForm.G3.Top - endingForm.T1.Height * 1);
            endingForm.T4.Location = new Point(endingForm.G4.Right - endingForm.T1.Width * 1, endingForm.G4.Top - endingForm.T1.Height * 1);
            endingForm.T5.Location = new Point(endingForm.G5.Right - endingForm.T1.Width * 1, endingForm.G5.Top - endingForm.T1.Height * 1);
            endingForm.T6.Location = new Point(endingForm.G6.Right - endingForm.T1.Width * 1, endingForm.G6.Top - endingForm.T1.Height * 1);
            endingForm.T7.Location = new Point(endingForm.G7.Right - endingForm.T1.Width * 1, endingForm.G7.Top - endingForm.T1.Height * 1);


            endingForm.T1.Text = line1TIMED + "s";
            endingForm.T2.Text = line2TIMED + "s";
            endingForm.T3.Text = line3TIMED + "s";
            endingForm.T4.Text = line4TIMED + "s";
            endingForm.T5.Text = line5TIMED + "s";
            endingForm.T6.Text = line6TIMED + "s";
            endingForm.T7.Text = line7TIMED + "s";


            int averageTime = (line1TIMED + line2TIMED + line3TIMED + line4TIMED + line5TIMED + line6TIMED + line7TIMED) / 7;


            endingForm.FullTime.Text = "Průměrný Čas: " + averageTime.ToString() + "s";

            
            endingForm.ShowDialog();
            

            line1TIME = 0;
            line2TIME = 0;
            line3TIME = 0;
            line4TIME = 0;
            line5TIME = 0;
            line6TIME = 0;
            line7TIME = 0;

            line1TIMED = 0;
            line2TIMED = 0;
            line3TIMED = 0;
            line4TIMED = 0;
            line5TIMED = 0;
            line6TIMED = 0;
            line7TIMED = 0;

            nehotovo = 7; Remain.Text = Convert.ToString(7 - nehotovo) + "/7";
            stop = false;
            BinarStart.Text = "Start";

            
        }

        int line1TIME = 0;
        int line2TIME = 0;
        int line3TIME = 0;
        int line4TIME = 0;
        int line5TIME = 0;
        int line6TIME = 0;
        int line7TIME = 0;

        int line1TIMED = 0;
        int line2TIMED = 0;
        int line3TIMED = 0;
        int line4TIMED = 0;
        int line5TIMED = 0;
        int line6TIMED = 0;
        int line7TIMED = 0;


        private void TimerLines_Tick(object sender, EventArgs e)
        {
            if (!stop) return;
            if (!testee) {
                line1TIME += Line1.Visible ? 1 : 0;
                line2TIME += Line2.Visible ? 1 : 0;
                line3TIME += Line3.Visible ? 1 : 0;
                line4TIME += Line4.Visible ? 1 : 0;
                line5TIME += Line5.Visible ? 1 : 0;
                line6TIME += Line6.Visible ? 1 : 0;
                line7TIME += Line7.Visible ? 1 : 0;
            }
            else
            {
                timertest -= 1;
                TimerTest.Text = "Zbývá: " + timertest.ToString() + " s";
                if (timertest <= 0)
                {
                    uspesnosttest = false;
                    TestKonec();
                }
            }
        }

        private void DecBin_CheckedChanged(object sender, EventArgs e)
        {
            if (!testee) { 
                label38.Visible = DecBin.Checked;
                Obtiznost.Visible = DecBin.Checked;
            }
            
        }

    }
}

 public static class Mezipamet
        {
            public static Dictionary<string, Dictionary<string, Dictionary<string, int>>> Cache { get; private set; } = new Dictionary<string, Dictionary<string, Dictionary<string, int>>>();

            static Mezipamet()
            {
                // Inicializace hlavní složky 'HlavniHistorie' pouze jednou
                Cache["HlavniHistorie"] = new Dictionary<string, Dictionary<string, int>>();
        
            }

            public static async Task PridatHistoriiAsync(int historie, int line1TIMED, int line2TIMED, int line3TIMED, int line4TIMED, int line5TIMED, int line6TIMED, int line7TIMED)
            {
                // Vytvoření nové historie s časovanými hodnotami
                var novaHistorie = new Dictionary<string, int>
        {
            { "Line1", line1TIMED },
            { "Line2", line2TIMED },
            { "Line3", line3TIMED },
            { "Line4", line4TIMED },
            { "Line5", line5TIMED },
            { "Line6", line6TIMED },
            { "Line7", line7TIMED }
        };

                // Přidání nové historie do 'HlavniHistorie'
                Cache["HlavniHistorie"].Add("Historie" + historie.ToString(), novaHistorie);

                // Tady můžete přidat další logiku, například asynchronní ukládání do databáze
            }
        }