﻿namespace Binar
{
    partial class TestEndingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestEndingForm));
            this.MovingPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.History = new Guna.UI2.WinForms.Guna2Button();
            this.Close = new Guna.UI2.WinForms.Guna2CircleButton();
            this.JmenoCviceni = new System.Windows.Forms.Label();
            this.Uspesnost = new System.Windows.Forms.Label();
            this.MovingPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // MovingPanel
            // 
            this.MovingPanel.BackColor = System.Drawing.Color.Transparent;
            this.MovingPanel.BorderColor = System.Drawing.Color.Black;
            this.MovingPanel.BorderRadius = 50;
            this.MovingPanel.BorderThickness = 3;
            this.MovingPanel.Controls.Add(this.History);
            this.MovingPanel.Controls.Add(this.Close);
            this.MovingPanel.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.MovingPanel.FillColor = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor2 = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor3 = System.Drawing.Color.Transparent;
            this.MovingPanel.FillColor4 = System.Drawing.Color.Transparent;
            this.MovingPanel.Location = new System.Drawing.Point(-15, -31);
            this.MovingPanel.Name = "MovingPanel";
            this.MovingPanel.Quality = 100;
            this.MovingPanel.Size = new System.Drawing.Size(434, 97);
            this.MovingPanel.TabIndex = 37;
            // 
            // History
            // 
            this.History.Animated = true;
            this.History.AutoRoundedCorners = true;
            this.History.BackColor = System.Drawing.Color.Transparent;
            this.History.BorderRadius = 21;
            this.History.Cursor = System.Windows.Forms.Cursors.Hand;
            this.History.CustomBorderColor = System.Drawing.Color.White;
            this.History.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.History.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.History.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.History.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.History.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.History.Font = new System.Drawing.Font("Arial Black", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.World);
            this.History.ForeColor = System.Drawing.Color.Olive;
            this.History.HoverState.BorderColor = System.Drawing.Color.Transparent;
            this.History.HoverState.CustomBorderColor = System.Drawing.Color.Transparent;
            this.History.HoverState.FillColor = System.Drawing.Color.Olive;
            this.History.HoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.History.Location = new System.Drawing.Point(798, 47);
            this.History.Name = "History";
            this.History.PressedDepth = 0;
            this.History.Size = new System.Drawing.Size(175, 45);
            this.History.TabIndex = 165;
            this.History.TabStop = false;
            this.History.Text = "Historie";
            this.History.TextOffset = new System.Drawing.Point(2, 0);
            // 
            // Close
            // 
            this.Close.Animated = true;
            this.Close.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.BorderThickness = 3;
            this.Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Close.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Close.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Close.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Close.FillColor = System.Drawing.Color.Maroon;
            this.Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Bold);
            this.Close.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Close.HoverState.ForeColor = System.Drawing.Color.Maroon;
            this.Close.Location = new System.Drawing.Point(27, 43);
            this.Close.Name = "Close";
            this.Close.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.Close.Size = new System.Drawing.Size(50, 50);
            this.Close.TabIndex = 33;
            this.Close.TabStop = false;
            this.Close.Text = "X";
            this.Close.TextOffset = new System.Drawing.Point(1, 1);
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // JmenoCviceni
            // 
            this.JmenoCviceni.Font = new System.Drawing.Font("Consolas", 35.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.JmenoCviceni.ForeColor = System.Drawing.Color.White;
            this.JmenoCviceni.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.JmenoCviceni.Location = new System.Drawing.Point(-2, 83);
            this.JmenoCviceni.Margin = new System.Windows.Forms.Padding(0);
            this.JmenoCviceni.Name = "JmenoCviceni";
            this.JmenoCviceni.Size = new System.Drawing.Size(403, 65);
            this.JmenoCviceni.TabIndex = 116;
            this.JmenoCviceni.Text = "---------";
            this.JmenoCviceni.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Uspesnost
            // 
            this.Uspesnost.Font = new System.Drawing.Font("Consolas", 50F, System.Drawing.FontStyle.Bold);
            this.Uspesnost.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Uspesnost.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Uspesnost.Location = new System.Drawing.Point(1, 188);
            this.Uspesnost.Margin = new System.Windows.Forms.Padding(0);
            this.Uspesnost.Name = "Uspesnost";
            this.Uspesnost.Size = new System.Drawing.Size(400, 89);
            this.Uspesnost.TabIndex = 117;
            this.Uspesnost.Text = "??????";
            this.Uspesnost.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // TestEndingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(400, 340);
            this.Controls.Add(this.Uspesnost);
            this.Controls.Add(this.JmenoCviceni);
            this.Controls.Add(this.MovingPanel);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TestEndingForm";
            this.Text = "T";
            this.Load += new System.EventHandler(this.TestEndingForm_Load);
            this.MovingPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public Guna.UI2.WinForms.Guna2CustomGradientPanel MovingPanel;
        private Guna.UI2.WinForms.Guna2Button History;
        public Guna.UI2.WinForms.Guna2CircleButton Close;
        public System.Windows.Forms.Label JmenoCviceni;
        public System.Windows.Forms.Label Uspesnost;
    }
}