﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Binar
{
    public partial class TestEndingForm : Form
    {
        private Point mouseDownLocation;

        public TestEndingForm()
        {
             InitializeComponent();
            MovingPanel.MouseDown += MovingPanel_MouseDown;
            MovingPanel.MouseMove += MovingPanel_MouseMove;
            MovingPanel.MouseUp += MovingPanel_MouseUp;
        }       
       
        private void MovingPanel_MouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                mouseDownLocation = e.Location;
            }
        }

        private void MovingPanel_MouseMove(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Left)
            {
                int deltaX = e.X - mouseDownLocation.X;
                int deltaY = e.Y - mouseDownLocation.Y;
                this.Location = new Point(this.Location.X + deltaX, this.Location.Y + deltaY);
            }
        }

        private void MovingPanel_MouseUp(object sender, MouseEventArgs e)
        {

            mouseDownLocation = Point.Empty;
        }
        private void TestEndingForm_Load(object sender, EventArgs e)
        {

        }

        private void Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
